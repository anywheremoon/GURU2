package com.example.medicineproject

import android.app.AlertDialog
import android.app.DatePickerDialog
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.view.LayoutInflater
import android.widget.*
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import com.example.medicineproject.db.DBHelper
import java.util.Calendar

class AddMedicineActivity : AppCompatActivity() {

    private lateinit var dbHelper: DBHelper
    private var medicineId: Long = -1L   // ⭐ 수정 모드 판별

    // 복용 일정 임시 저장용
    private val schedules = mutableListOf<ScheduleInput>()

    private lateinit var imgMedicine: ImageView
    private lateinit var btnSelectImage: Button
    private var selectedImageUri: Uri? = null

    private val imagePickerLauncher =
        registerForActivityResult(ActivityResultContracts.GetContent()) { uri ->
            uri?.let {
                selectedImageUri = it

                // 🔥 핵심: 권한 유지
                contentResolver.takePersistableUriPermission(
                    it,
                    Intent.FLAG_GRANT_READ_URI_PERMISSION
                )

                imgMedicine.setImageURI(it)
            }
        }

    data class ScheduleInput(
        val timeType: String,
        val amount: Int,
        val unit: String,
        val startDate: String,
        val endDate: String
    )

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_add_medicine)

        dbHelper = DBHelper(this)
        medicineId = intent.getLongExtra("medicine_id", -1L)

        val etName = findViewById<EditText>(R.id.etMedicineName)
        val spinnerCategory = findViewById<Spinner>(R.id.spinnerCategory)
        val btnAddSchedule = findViewById<Button>(R.id.btnAddSchedule)
        val btnSave = findViewById<Button>(R.id.btnSaveMedicine)
        val containerSchedules = findViewById<LinearLayout>(R.id.containerSchedules)

        imgMedicine = findViewById(R.id.imgMedicine)
        btnSelectImage = findViewById(R.id.btnSelectImage)

        btnSelectImage.setOnClickListener {
            imagePickerLauncher.launch("image/*")
        }


        // 카테고리 스피너
        val categories = listOf("처방약", "일반약", "영양제")
        spinnerCategory.adapter = ArrayAdapter(
            this,
            android.R.layout.simple_spinner_dropdown_item,
            categories
        )

        // --------------------
        // ⭐ 수정 모드면 기존 데이터 로드
        // --------------------
        if (medicineId != -1L) {
            title = "약 정보 수정"

            val db = dbHelper.readableDatabase

            // 1️⃣ medicine 정보
            val c1 = db.rawQuery(
                "SELECT name, category, photo_uri FROM medicine WHERE medicine_id = ?",
                arrayOf(medicineId.toString())
            )
            if (c1.moveToFirst()) {
                etName.setText(c1.getString(0))

                val category = c1.getString(1)
                for (i in categories.indices) {
                    if (categories[i] == category) {
                        spinnerCategory.setSelection(i)
                        break
                    }
                }

                // 🔥 사진 복원
                val photoUri = c1.getString(2)
                if (!photoUri.isNullOrEmpty()) {
                    selectedImageUri = Uri.parse(photoUri)
                    imgMedicine.setImageURI(selectedImageUri)
                }
            }

            c1.close()

            // 2️⃣ dose_schedule 로드
            val c2 = db.rawQuery(
                """
                SELECT time_type, amount, unit, start_date, end_date
                FROM dose_schedule
                WHERE medicine_id = ?
                ORDER BY
                    CASE time_type
                        WHEN '아침' THEN 1
                        WHEN '점심' THEN 2
                        WHEN '저녁' THEN 3
                        WHEN '취침 전' THEN 4
                        ELSE 99
                    END
                """.trimIndent(),
                arrayOf(medicineId.toString())
            )

            schedules.clear()
            while (c2.moveToNext()) {
                schedules.add(
                    ScheduleInput(
                        timeType = c2.getString(0),
                        amount = c2.getInt(1),
                        unit = c2.getString(2),
                        startDate = c2.getString(3),
                        endDate = c2.getString(4)
                    )
                )
            }
            c2.close()

            renderSchedules(containerSchedules)
        } else {
            title = "약 추가"
        }

        // --------------------
        // 복용 시간 추가
        // --------------------
        btnAddSchedule.setOnClickListener {
            showAddScheduleDialog { schedule ->
                schedules.add(schedule)
                renderSchedules(containerSchedules)
            }
        }

        // --------------------
        // 저장 버튼
        // --------------------
        btnSave.setOnClickListener {
            val name = etName.text.toString().trim()
            val category = spinnerCategory.selectedItem.toString()

            if (name.isEmpty()) {
                toast("약 이름을 입력해주세요")
                return@setOnClickListener
            }
            if (schedules.isEmpty()) {
                toast("복용 시간을 최소 1개는 추가해주세요")
                return@setOnClickListener
            }

            val db = dbHelper.writableDatabase

            if (medicineId == -1L) {
                // ▶ 추가
                val newId = dbHelper.insertMedicine(
                    name = name,
                    category = category,
                    photoUri = selectedImageUri?.toString()
                )

                for (s in schedules) {
                    dbHelper.insertDoseSchedule(
                        medicineId = newId,
                        timeType = s.timeType,
                        amount = s.amount,
                        unit = s.unit,
                        startDate = s.startDate,
                        endDate = s.endDate
                    )
                }

                toast("약 등록 완료")
            } else {
                // ▶ 수정
                dbHelper.updateMedicine(
                    medicineId = medicineId,
                    name = name,
                    category = category,
                    photoUri = selectedImageUri?.toString()
                )

                // 기존 스케줄 삭제 후 재삽입 (가장 안전)
                db.execSQL(
                    "DELETE FROM dose_schedule WHERE medicine_id = ?",
                    arrayOf(medicineId)
                )

                for (s in schedules) {
                    dbHelper.insertDoseSchedule(
                        medicineId = medicineId,
                        timeType = s.timeType,
                        amount = s.amount,
                        unit = s.unit,
                        startDate = s.startDate,
                        endDate = s.endDate
                    )
                }

                toast("약 정보 수정 완료")
            }

            finish()
        }
    }

    // --------------------
    // 스케줄 미리보기 렌더
    // --------------------
    private fun renderSchedules(container: LinearLayout) {
        container.removeAllViews()

        if (schedules.isEmpty()) {
            val tv = TextView(this).apply {
                text = "아직 추가된 복용 시간이 없어."
            }
            container.addView(tv)
            return
        }

        schedules.forEachIndexed { idx, s ->
            val row = LayoutInflater.from(this)
                .inflate(R.layout.item_schedule_preview, container, false)

            val tvInfo = row.findViewById<TextView>(R.id.tvScheduleInfo)
            val btnDelete = row.findViewById<ImageButton>(R.id.btnDeleteSchedule)

            tvInfo.text =
                "${s.timeType}  |  ${s.amount}${s.unit}  |  ${s.startDate} ~ ${s.endDate}"

            btnDelete.setOnClickListener {
                schedules.removeAt(idx)
                renderSchedules(container)
            }

            container.addView(row)
        }
    }

    private fun showDatePicker(target: EditText) {
        val cal = Calendar.getInstance()

        DatePickerDialog(
            this,   // ← 여기 중요: Activity 컨텍스트
            { _, year, month, day ->
                val date = String.format(
                    "%04d-%02d-%02d",
                    year,
                    month + 1,
                    day
                )
                target.setText(date)
            },
            cal.get(Calendar.YEAR),
            cal.get(Calendar.MONTH),
            cal.get(Calendar.DAY_OF_MONTH)
        ).show()
    }


    // --------------------
    // 복용 시간 추가 다이얼로그
    // --------------------
    private fun showAddScheduleDialog(onAdded: (ScheduleInput) -> Unit) {
        val dialogView = LayoutInflater.from(this)
            .inflate(R.layout.dialog_add_schedule, null)

        val spinnerTime = dialogView.findViewById<Spinner>(R.id.spinnerTimeType)
        val etAmount = dialogView.findViewById<EditText>(R.id.etDoseAmount)
        val etUnit = dialogView.findViewById<EditText>(R.id.etDoseUnit)
        val etStart = dialogView.findViewById<EditText>(R.id.etStartDate)
        val etEnd = dialogView.findViewById<EditText>(R.id.etEndDate)
        val cbNoEndDate = dialogView.findViewById<CheckBox>(R.id.cbNoEndDate)


        etStart.setOnClickListener {
            showDatePicker(etStart)
        }

        etEnd.setOnClickListener {
            showDatePicker(etEnd)
        }

        val timeTypes = listOf("아침", "점심", "저녁", "취침 전")
        spinnerTime.adapter = ArrayAdapter(
            this,
            android.R.layout.simple_spinner_dropdown_item,
            timeTypes
        )

        cbNoEndDate.setOnCheckedChangeListener { _, isChecked ->
            etEnd.isEnabled = !isChecked
            if (isChecked) {
                etEnd.setText("")
            }
        }

        AlertDialog.Builder(this)
            .setTitle("복용 시간 추가")
            .setView(dialogView)
            .setPositiveButton("추가") { _, _ ->
                val timeType = spinnerTime.selectedItem.toString()
                val amount = etAmount.text.toString().toIntOrNull()
                val unit = etUnit.text.toString().trim()
                val startDate = etStart.text.toString().trim()
                val endDate =
                    if (cbNoEndDate.isChecked) "9999-12-31"
                    else etEnd.text.toString().trim()

                if (!isValidDate(startDate)) {
                    toast("시작일을 선택해주세요")
                    return@setPositiveButton
                }

                if (!cbNoEndDate.isChecked) {
                    if (!isValidDate(endDate)) {
                        toast("종료일을 선택해주세요")
                        return@setPositiveButton
                    }
                    if (startDate > endDate) {
                        toast("종료일은 시작일 이후로 설정해주세요")
                        return@setPositiveButton
                    }
                }



                if (amount == null || amount <= 0) {
                    toast("용량(숫자)을 제대로 입력해주세요")
                    return@setPositiveButton
                }
                if (unit.isEmpty()) {
                    toast("단위를 입력해주세요 (예: 정, ml)")
                    return@setPositiveButton
                }
                if (!isValidDate(startDate) || !isValidDate(endDate)) {
                    toast("날짜는 yyyy-MM-dd 형식으로 입력해주세요")
                    return@setPositiveButton
                }

                onAdded(
                    ScheduleInput(
                        timeType = timeType,
                        amount = amount,
                        unit = unit,
                        startDate = startDate,
                        endDate = endDate
                    )
                )
            }
            .setNegativeButton("취소", null)
            .show()
    }

    private fun isValidDate(s: String): Boolean {
        return Regex("""\d{4}-\d{2}-\d{2}""").matches(s)
    }

    private fun toast(msg: String) {
        Toast.makeText(this, msg, Toast.LENGTH_SHORT).show()
    }
}
