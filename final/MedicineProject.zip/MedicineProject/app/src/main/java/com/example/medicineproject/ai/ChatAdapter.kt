package com.example.medicineproject.ai

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import com.example.medicineproject.R

class ChatAdapter(
    private val items: List<ChatMessage>
) : RecyclerView.Adapter<RecyclerView.ViewHolder>() {

    private companion object {
        const val VT_USER = 1
        const val VT_AI = 2
    }

    override fun getItemViewType(position: Int): Int {
        return when (items[position].role) {
            ChatRole.USER -> VT_USER
            ChatRole.ASSISTANT -> VT_AI
        }
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): RecyclerView.ViewHolder {
        val inflater = LayoutInflater.from(parent.context)
        return when (viewType) {
            VT_USER -> {
                val v = inflater.inflate(R.layout.item_chat_user, parent, false)
                UserVH(v)
            }
            else -> {
                val v = inflater.inflate(R.layout.item_chat_ai, parent, false)
                AiVH(v)
            }
        }
    }

    override fun onBindViewHolder(holder: RecyclerView.ViewHolder, position: Int) {
        val item = items[position]
        when (holder) {
            is UserVH -> holder.bind(item)
            is AiVH -> holder.bind(item)
        }
    }

    override fun getItemCount(): Int = items.size

    class UserVH(itemView: View) : RecyclerView.ViewHolder(itemView) {
        private val tv = itemView.findViewById<TextView>(R.id.tvMessage)
        fun bind(item: ChatMessage) {
            tv.text = item.text
        }
    }

    class AiVH(itemView: View) : RecyclerView.ViewHolder(itemView) {
        private val tv = itemView.findViewById<TextView>(R.id.tvMessage)
        fun bind(item: ChatMessage) {
            tv.text = item.text
        }
    }
}