package com.example.medicineproject

import android.database.sqlite.SQLiteDatabase
import android.graphics.Color
import android.os.Bundle
import android.util.Log
import android.view.View
import android.widget.TextView
import androidx.fragment.app.Fragment
import com.example.medicineproject.calendar.ColorDecorator
import com.example.medicineproject.db.DBHelper
import com.prolificinteractive.materialcalendarview.CalendarDay
import com.prolificinteractive.materialcalendarview.MaterialCalendarView
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Locale

/**
 * 캘린더 화면 Fragment
 *
 * - 월별 캘린더 표시
 * - 날짜별 복용 상태를 색상으로 시각화
 *   (완료 / 일부 / 미복용)
 * - 날짜 선택 시 상세 복용 내역 표시
 */
class CalendarFragment : Fragment(R.layout.fragment_calendar) {

    // DB에 저장된 날짜 형식과 맞추기 위한 포맷
    private val dateFormat = SimpleDateFormat("yyyy-MM-dd", Locale.KOREA)

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        // UI 바인딩
        val calendarView = view.findViewById<MaterialCalendarView>(R.id.calendarView)
        val tvStatus = view.findViewById<TextView>(R.id.tvStatus)
        val tvDetail = view.findViewById<TextView>(R.id.tvDetail)

        val btnPrevMonth = view.findViewById<View>(R.id.btnPrevMonth)
        val btnNextMonth = view.findViewById<View>(R.id.btnNextMonth)
        val tvMonthLabel = view.findViewById<TextView>(R.id.tvMonthLabel)

        // DB 읽기 전용 연결
        val db = DBHelper(requireContext()).readableDatabase

        // 기본 캘린더 상단 바 숨김 (커스텀 월 이동 UI 사용)
        calendarView.topbarVisible = false

        // =========================
        // 월 표시 텍스트 갱신
        // =========================
        fun updateMonthLabel(date: CalendarDay) {
            val cal = Calendar.getInstance()
            cal.set(date.year, date.month, 1)

            val fmt = SimpleDateFormat("M월", Locale.KOREA)
            tvMonthLabel.text = fmt.format(cal.time)
        }

        // =========================
        // 캘린더 색상 상태 갱신
        // =========================
        fun refreshCalendar(year: Int, month0: Int) {

            // 날짜 상태별 리스트
            val completeDates = mutableListOf<CalendarDay>() // 모두 복용
            val partialDates = mutableListOf<CalendarDay>()  // 일부 복용
            val failDates = mutableListOf<CalendarDay>()     // 전부 미복용

            val cal = Calendar.getInstance()
            cal.set(year, month0, 1)
            val daysInMonth = cal.getActualMaximum(Calendar.DAY_OF_MONTH)

            // 월의 모든 날짜 순회
            for (day in 1..daysInMonth) {
                cal.set(year, month0, day)
                val dateStr = dateFormat.format(cal.time)

                /**
                 * 날짜별 복용 상태 계산 쿼리
                 * - total: 해당 날짜에 예정된 복용 스케줄 수
                 * - untaken_count: 아직 복용하지 않은 스케줄 수
                 */
                val cursor = db.rawQuery(
                    """
                    SELECT
                        COUNT(DISTINCT d.schedule_id) AS total,
                        COUNT(DISTINCT CASE 
                            WHEN i.taken = 0 OR i.taken IS NULL 
                            THEN d.schedule_id 
                        END) AS untaken_count
                    FROM dose_schedule d
                    LEFT JOIN intake_log i
                      ON i.schedule_id = d.schedule_id
                     AND i.date = ?
                    WHERE ? BETWEEN d.start_date AND d.end_date
                    """.trimIndent(),
                    arrayOf(dateStr, dateStr)
                )

                if (cursor.moveToFirst()) {
                    val total = cursor.getInt(0)
                    val untaken = cursor.getInt(1)

                    // 해당 날짜에 복용 일정이 있는 경우만 처리
                    if (total > 0) {
                        Log.d(
                            "CalendarCheck",
                            "날짜: $dateStr, 전체: $total, 미복용: $untaken"
                        )

                        val calendarDay = CalendarDay.from(year, month0, day)

                        // 복용 상태에 따라 날짜 분류
                        when {
                            untaken == 0 ->
                                completeDates.add(calendarDay)   // 전부 복용

                            untaken == total ->
                                failDates.add(calendarDay)       // 전부 미복용

                            else ->
                                partialDates.add(calendarDay)    // 일부 복용
                        }
                    }
                }
                cursor.close()
            }

            // 기존 데코레이터 제거 후 상태별 색상 적용
            calendarView.removeDecorators()
            calendarView.addDecorator(
                ColorDecorator(Color.parseColor("#2E7D32"), completeDates)
            )
            calendarView.addDecorator(
                ColorDecorator(Color.parseColor("#F59E0B"), partialDates)
            )
            calendarView.addDecorator(
                ColorDecorator(Color.parseColor("#D32F2F"), failDates)
            )
            calendarView.invalidateDecorators()
        }

        // =========================
        // 월 이동 버튼
        // =========================
        btnPrevMonth.setOnClickListener { calendarView.goToPrevious() }
        btnNextMonth.setOnClickListener { calendarView.goToNext() }

        // =========================
        // 초기 상태 (오늘 날짜)
        // =========================
        val todayDay = CalendarDay.today()
        calendarView.setSelectedDate(todayDay)
        updateMonthLabel(todayDay)
        refreshCalendar(todayDay.year, todayDay.month)
        showDateDetail(todayDay, db, tvStatus, tvDetail)

        // =========================
        // 월 변경 리스너
        // =========================
        calendarView.setOnMonthChangedListener { _, date ->
            updateMonthLabel(date)
            refreshCalendar(date.year, date.month)
        }

        // =========================
        // 날짜 선택 리스너
        // =========================
        calendarView.setOnDateChangedListener { _, date, _ ->
            showDateDetail(date, db, tvStatus, tvDetail)
        }
    }

    // =========================
    // 날짜 상세 복용 내역 표시
    // =========================
    private fun showDateDetail(
        date: CalendarDay,
        db: SQLiteDatabase,
        tvStatus: TextView,
        tvDetail: TextView
    ) {
        // 선택된 날짜를 DB 형식으로 변환
        val selectedDate = String.format(
            "%04d-%02d-%02d",
            date.year,
            date.month + 1,
            date.day
        )

        /**
         * 선택한 날짜의 복용 내역 조회
         * - 시간대별로 약 이름과 복용 여부 가져오기
         */
        val cursor = db.rawQuery(
            """
            SELECT d.time_type, m.name, COALESCE(i.taken, 0)
            FROM dose_schedule d
            JOIN medicine m ON d.medicine_id = m.medicine_id
            LEFT JOIN intake_log i
              ON i.schedule_id = d.schedule_id
             AND i.date = ?
            WHERE ? BETWEEN d.start_date AND d.end_date
            ORDER BY
                CASE d.time_type
                    WHEN '아침' THEN 1
                    WHEN '점심' THEN 2
                    WHEN '저녁' THEN 3
                    WHEN '취침 전' THEN 4
                    ELSE 99
                END
            """.trimIndent(),
            arrayOf(selectedDate, selectedDate)
        )

        // 시간대별로 데이터 묶기
        val grouped = linkedMapOf<String, MutableList<Pair<String, Boolean>>>()

        while (cursor.moveToNext()) {
            val timeType = cursor.getString(0)
            val name = cursor.getString(1)
            val taken = cursor.getInt(2) == 1

            grouped.getOrPut(timeType) { mutableListOf() }
                .add(name to taken)
        }
        cursor.close()

        // 화면에 표시할 문자열 생성
        val sb = StringBuilder()
        for (time in listOf("아침", "점심", "저녁", "취침 전")) {
            val list = grouped[time] ?: continue
            sb.append("$time\n")

            for ((name, taken) in list) {
                sb.append("    ${if (taken) "✅" else "❌"} $name\n")
            }
            sb.append("\n")
        }

        // UI 업데이트
        tvStatus.text = selectedDate
        tvDetail.text =
            if (sb.isNotEmpty()) sb.toString().trim()
            else "등록된 복용 일정이 없습니다."
    }
}
