package com.example.medicineproject.ai

import android.os.Bundle
import android.widget.EditText
import android.widget.ImageButton
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.example.medicineproject.R
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

class AIChatActivity : AppCompatActivity() {

    private lateinit var rvChat: RecyclerView
    private lateinit var etMessage: EditText
    private lateinit var btnSend: ImageButton
    private lateinit var btnBack: TextView

    private val messages = mutableListOf<ChatMessage>()
    private lateinit var adapter: ChatAdapter

    // Fragment에서 전달받는 컨텍스트
    private var selectedNames: List<String> = emptyList()
    private var localResult: String = ""

    private var isSending: Boolean = false

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_ai_chat)

        rvChat = findViewById(R.id.rvChat)
        etMessage = findViewById(R.id.etMessage)
        btnSend = findViewById(R.id.btnSend)
        btnBack = findViewById(R.id.btnBack)

        selectedNames = intent.getStringArrayListExtra("selectedNames") ?: emptyList()
        localResult = intent.getStringExtra("localResult").orEmpty()

        adapter = ChatAdapter(messages)
        rvChat.layoutManager = LinearLayoutManager(this).apply { stackFromEnd = true }
        rvChat.adapter = adapter

        btnBack.setOnClickListener { finish() }

        val intro = buildString {
            append("안녕! 선택한 조합을 바탕으로 같이 정리해볼게 😊\n")
            if (selectedNames.isNotEmpty()) {
                append("\n[선택한 영양제]\n")
                append(selectedNames.joinToString(", "))
                append("\n")
            }
            if (localResult.isNotBlank()) {
                append("\n[앱 조합 분석 결과]\n")
                append(localResult)
                append("\n")
            }
            append("\n궁금한 걸 질문해줘! (예: 같이 먹어도 돼?, 시간 간격은?, 주의할 증상은?)")
        }
        addMessage(ChatMessage(role = ChatRole.ASSISTANT, text = intro))

        btnSend.setOnClickListener {
            val text = etMessage.text?.toString()?.trim().orEmpty()
            if (text.isBlank()) return@setOnClickListener
            if (isSending) return@setOnClickListener

            etMessage.setText("")
            addMessage(ChatMessage(role = ChatRole.USER, text = text))
            sendToAI()
        }
    }

    private fun addMessage(msg: ChatMessage) {
        messages.add(msg)
        adapter.notifyItemInserted(messages.lastIndex)
        rvChat.scrollToPosition(messages.lastIndex)
    }

    private fun buildContext(): String {
        return buildString {
            appendLine("너는 '영양제/건강기능식품 복용 기록 앱(약속)'의 AI 상담 도우미야.")
            appendLine("의료적 진단/처방/단정은 절대 하지 말고, 일반 정보 수준으로만 안내해.")
            appendLine("사용자의 개인 상태/복용 중인 약/질환에 따라 달라질 수 있으니, 필요 시 약사/의사 상담을 권고해.")
            appendLine()
            if (selectedNames.isNotEmpty()) {
                appendLine("[사용자가 선택한 영양제]")
                appendLine(selectedNames.joinToString(", "))
                appendLine()
            }
            if (localResult.isNotBlank()) {
                appendLine("[앱 내부 룰 기반 결과]")
                appendLine(localResult)
                appendLine()
            }
            appendLine("대화는 한국어로, 따뜻하고 친근하지만 과하게 오글거리지는 않게.")
            appendLine("가능하면 bullet로 핵심부터 짧게 정리해.")
            appendLine("마지막에는 다음 문구를 붙여:")
            appendLine("※ 개인 상태에 따라 다를 수 있어요. 필요 시 전문가와 상담하세요.")
        }.trim()
    }

    private fun sendToAI() {
        // 마지막 N개만 보내서 토큰 폭발 방지
        val recent = messages.takeLast(12)

        isSending = true
        btnSend.isEnabled = false

        // 로딩 버블
        val loadingIndex = messages.size
        addMessage(ChatMessage(role = ChatRole.ASSISTANT, text = "🤖 답변 작성 중…"))

        lifecycleScope.launch(Dispatchers.IO) {
            val result = OpenAIClient.requestChat(
                context = buildContext(),
                history = recent
            )

            withContext(Dispatchers.Main) {
                // 로딩 메시지 교체
                val reply = if (result.isSuccess) {
                    result.getOrNull().orEmpty().ifBlank { "(답변을 불러오지 못했어요. 잠시 후 다시 시도해줘.)" }
                } else {
                    val msg = result.exceptionOrNull()?.message.orEmpty()
                    if (msg.contains("API Key")) {
                        "(AI 상담을 쓰려면 OpenAIClient.apiKey 를 설정해줘!)"
                    } else {
                        "(AI 상담을 불러오지 못했어요. 네트워크/키 설정을 확인해줘.)"
                    }
                }

                // loadingIndex가 유효하면 교체
                if (loadingIndex in messages.indices) {
                    messages[loadingIndex] = ChatMessage(role = ChatRole.ASSISTANT, text = reply)
                    adapter.notifyItemChanged(loadingIndex)
                    rvChat.scrollToPosition(messages.lastIndex)
                } else {
                    addMessage(ChatMessage(role = ChatRole.ASSISTANT, text = reply))
                }

                isSending = false
                btnSend.isEnabled = true
            }
        }
    }
}