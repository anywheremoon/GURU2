package com.example.medicineproject

import android.animation.ValueAnimator
import android.os.Bundle
import android.view.View
import android.view.animation.DecelerateInterpolator
import android.widget.ImageButton
import android.widget.ProgressBar
import android.widget.TextView
import androidx.fragment.app.Fragment
import com.example.medicineproject.db.DBHelper
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class StatsFragment : Fragment(R.layout.fragment_stats) {

    private enum class Mode { WEEKLY, MONTHLY }
    private var mode: Mode = Mode.MONTHLY

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        val tvRate = view.findViewById<TextView>(R.id.tvRate)
        val progress = view.findViewById<ProgressBar>(R.id.progressRate)
        val tvRateCenter = view.findViewById<TextView>(R.id.tvRateCenter)
        val tvComment = view.findViewById<TextView>(R.id.tvComment)

        val tvSummary = view.findViewById<TextView>(R.id.tvSummary)

        val tvTotalCount = view.findViewById<TextView>(R.id.tvTotalCount)
        val tvDoneCount = view.findViewById<TextView>(R.id.tvDoneCount)
        val tvMissedCount = view.findViewById<TextView>(R.id.tvMissedCount)

        val tvPeriod = view.findViewById<TextView>(R.id.tvPeriod)

        val btnPrev = view.findViewById<ImageButton>(R.id.btnPrev)
        val btnNext = view.findViewById<ImageButton>(R.id.btnNext)

        val dbHelper = DBHelper(requireContext())

        fun render() {
            val summary = when (mode) {
                Mode.MONTHLY -> {
                    val month = SimpleDateFormat("yyyy-MM", Locale.KOREA).format(Date())
                    tvPeriod.text = "이번 달"
                    dbHelper.getMonthlySummary(month)
                }
                Mode.WEEKLY -> {
                    tvPeriod.text = "최근 7일"
                    dbHelper.getWeeklySummary(7)
                }
            }

            val rate = dbHelper.calcRatePercent(summary)

            tvRate.text = when (mode) {
                Mode.MONTHLY -> "이번 달 복용률: ${rate}%"
                Mode.WEEKLY -> "최근 7일 복용률: ${rate}%"
            }


            animateProgress(progress, tvRateCenter, rate)


            tvComment.text = when {
                summary.total == 0 -> "아직 복용 기록이 없어요. 오늘부터 시작해볼까요?"
                rate == 100 -> "완벽해요 👏 지금처럼만 유지하면 돼요!"
                rate >= 80 -> "아주 잘하고 있어요 👍"
                rate >= 50 -> "괜찮아요. 조금만 더 신경 써보면 좋아요!"
                else -> "이번 달에는 진행 중인 복용 일정이 있어요."
            }

            tvTotalCount.text = "${summary.total}회"
            tvDoneCount.text = "${summary.done}회"
            tvMissedCount.text = "${summary.missed}회"

            tvSummary.text =
                "총 복용 예정: ${summary.total}회\n" +
                        "복용 완료: ${summary.done}회\n" +
                        "미복용: ${summary.missed}회"
        }

        // 초기 화면
        mode = Mode.MONTHLY
        render()

        // 주간 / 월간 전환
        btnPrev.setOnClickListener {
            mode = if (mode == Mode.MONTHLY) Mode.WEEKLY else Mode.MONTHLY
            render()
        }

        btnNext.setOnClickListener {
            mode = if (mode == Mode.MONTHLY) Mode.WEEKLY else Mode.MONTHLY
            render()
        }
    }

    private fun animateProgress(
        progressBar: ProgressBar,
        tvCenter: TextView,
        target: Int
    ) {
        progressBar.progress = 0
        tvCenter.text = "0%"

        val animator = ValueAnimator.ofInt(0, target)
        animator.duration = 1000L
        animator.interpolator = DecelerateInterpolator()

        animator.addUpdateListener { animation ->
            val value = animation.animatedValue as Int
            progressBar.progress = value
            tvCenter.text = "${value}%"
        }

        animator.start()
    }
}
