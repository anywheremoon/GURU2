package com.example.medicineproject.alarm

import android.app.AlarmManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import com.example.medicineproject.db.DBHelper
import java.text.SimpleDateFormat
import java.util.*

object AlarmScheduler {

    // =========================
    // 개별 알람 스케줄
    // =========================
    fun schedule(
        context: Context,
        requestCode: Int,
        hour: Int,
        minute: Int,
        timeType: String
    ) {
        val alarmManager =
            context.getSystemService(Context.ALARM_SERVICE) as AlarmManager

        val intent = Intent(context, MedicineAlarmReceiver::class.java).apply {
            putExtra("time_type", timeType)
        }

        val pendingIntent = PendingIntent.getBroadcast(
            context,
            requestCode,
            intent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        val cal = Calendar.getInstance().apply {
            set(Calendar.HOUR_OF_DAY, hour)
            set(Calendar.MINUTE, minute)
            set(Calendar.SECOND, 0)
            set(Calendar.MILLISECOND, 0)

            // 이미 지난 시간이면 다음 날
            if (before(Calendar.getInstance())) {
                add(Calendar.DAY_OF_MONTH, 1)
            }
        }

        alarmManager.setExactAndAllowWhileIdle(
            AlarmManager.RTC_WAKEUP,
            cal.timeInMillis,
            pendingIntent
        )
    }

    // =========================
    // 알람 취소
    // =========================
    fun cancel(
        context: Context,
        requestCode: Int
    ) {
        val alarmManager =
            context.getSystemService(Context.ALARM_SERVICE) as AlarmManager

        val intent = Intent(context, MedicineAlarmReceiver::class.java)

        val pendingIntent = PendingIntent.getBroadcast(
            context,
            requestCode,
            intent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        alarmManager.cancel(pendingIntent)
    }

    // =========================
    // 오늘 알람 전체 재스케줄
    // =========================
    fun rescheduleToday(context: Context) {
        val prefs = context.getSharedPreferences("alarm_prefs", Context.MODE_PRIVATE)

        // 알람 OFF면 전부 취소
        if (!prefs.getBoolean("alarm_enabled", true)) {
            for (code in 100..103) {
                cancel(context, code)
            }
            return
        }

        val dbHelper = DBHelper(context)
        val today = SimpleDateFormat("yyyy-MM-dd", Locale.KOREA).format(Date())
        val timeTypes = dbHelper.getTodayTimeTypes(today)

        // 기존 알람 전부 정리
        for (code in 100..103) {
            cancel(context, code)
        }

        timeTypes.forEach { type ->
            if (dbHelper.isTimeTypeCompleted(today, type)) return@forEach

            when (type) {
                "아침" -> schedule(
                    context, 100,
                    prefs.getInt("morning_hour", 8),
                    prefs.getInt("morning_min", 0),
                    "아침"
                )

                "점심" -> schedule(
                    context, 101,
                    prefs.getInt("lunch_hour", 12),
                    prefs.getInt("lunch_min", 30),
                    "점심"
                )

                "저녁" -> schedule(
                    context, 102,
                    prefs.getInt("dinner_hour", 18),
                    prefs.getInt("dinner_min", 30),
                    "저녁"
                )

                "취침 전" -> schedule(
                    context, 103,
                    prefs.getInt("bedtime_hour", 22),
                    prefs.getInt("bedtime_min", 0),
                    "취침 전"
                )
            }
        }
    }
}
