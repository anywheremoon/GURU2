package com.example.medicineproject

import android.content.Intent
import android.graphics.Typeface
import android.os.Bundle
import android.text.SpannableStringBuilder
import android.text.Spanned
import android.text.style.StyleSpan
import android.view.Menu
import android.view.MenuItem
import android.widget.Button
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.appcompat.widget.Toolbar
import com.example.medicineproject.db.DBHelper
import com.google.android.material.dialog.MaterialAlertDialogBuilder
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class PillDetailActivity : AppCompatActivity() {

    private lateinit var dbHelper: DBHelper
    private var medicineId: Long = -1L

    private lateinit var tvCategory: TextView
    private lateinit var tvSchedules: TextView
    private lateinit var tvLastTaken: TextView

    private val today: String by lazy {
        SimpleDateFormat("yyyy-MM-dd", Locale.KOREA).format(Date())
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_pill_detail)

        dbHelper = DBHelper(this)
        medicineId = intent.getLongExtra("medicine_id", -1L)

        if (medicineId == -1L) {
            finish()
            return
        }

        val toolbar = findViewById<Toolbar>(R.id.toolbar)
        setSupportActionBar(toolbar)
        supportActionBar?.setDisplayHomeAsUpEnabled(true)

        tvCategory = findViewById(R.id.tvCategory)
        tvSchedules = findViewById(R.id.tvSchedules)
        tvLastTaken = findViewById(R.id.tvLastTaken)

        val btnTake = findViewById<Button>(R.id.btnTake)
        btnTake.setOnClickListener { handleTake() }

        loadMedicineInfo() // 최초 로딩
    }

    override fun onResume() {
        super.onResume()
        loadMedicineInfo()
    }

    // --------------------
    // DB에서 약 정보 다시 로딩
    // --------------------
    private fun loadMedicineInfo() {
        val db = dbHelper.readableDatabase

        // 1) 약 기본 정보
        val c1 = db.rawQuery(
            "SELECT name, category FROM medicine WHERE medicine_id = ?",
            arrayOf(medicineId.toString())
        )
        if (c1.moveToFirst()) {
            val name = c1.getString(0)
            val category = c1.getString(1) ?: "-"
            setBoldLabel(tvCategory, "분류:", category)
            supportActionBar?.title = name
        }
        c1.close()

        // 2) 스케줄 목록
        val lines = StringBuilder()
        val c2 = db.rawQuery(
            """
            SELECT time_type, amount, unit
            FROM dose_schedule
            WHERE medicine_id = ?
            """.trimIndent(),
            arrayOf(medicineId.toString())
        )
        while (c2.moveToNext()) {
            lines.append("- ${c2.getString(0)} : ${c2.getInt(1)}${c2.getString(2)}\n")
        }
        c2.close()

        val scheduleLines = lines.toString().trim()
        if (scheduleLines.isNotEmpty()) {
            setBoldLabelMultiline(tvSchedules, "복용 시간:", scheduleLines)
        } else {
            setBoldLabel(tvSchedules, "복용 시간:", "-")
        }

        // 3) 마지막 복용 날짜
        val c3 = db.rawQuery(
            """
            SELECT MAX(date)
            FROM intake_log
            WHERE schedule_id IN (
                SELECT schedule_id FROM dose_schedule WHERE medicine_id = ?
            )
            """.trimIndent(),
            arrayOf(medicineId.toString())
        )

        if (c3.moveToFirst() && c3.getString(0) != null) {
            setBoldLabel(tvLastTaken, "마지막 복용:", c3.getString(0))
        } else {
            tvLastTaken.text = "아직 복용 기록 없어요"
        }
        c3.close()
    }

    // --------------------
    // 먹음 처리
    // --------------------
    private fun handleTake() {
        val db = dbHelper.readableDatabase

        val c = db.rawQuery(
            """
            SELECT COUNT(*)
            FROM intake_log
            WHERE date = ?
            AND schedule_id IN (
                SELECT schedule_id FROM dose_schedule WHERE medicine_id = ?
            )
            """.trimIndent(),
            arrayOf(today, medicineId.toString())
        )

        val alreadyTaken = c.moveToFirst() && c.getInt(0) > 0
        c.close()

        if (alreadyTaken) {
            MaterialAlertDialogBuilder(this)
                .setTitle("중복 복용 경고")
                .setMessage("오늘 이미 이 약을 복용했어요.\n그래도 다시 기록할까요?")
                .setPositiveButton("그래도 기록") { _, _ ->
                    markTaken()
                }
                .setNegativeButton("취소", null)
                .show()
        } else {
            markTaken()
        }
    }

    private fun markTaken() {
        val db = dbHelper.writableDatabase

        val c = db.rawQuery(
            "SELECT schedule_id FROM dose_schedule WHERE medicine_id = ?",
            arrayOf(medicineId.toString())
        )

        while (c.moveToNext()) {
            val scheduleId = c.getInt(0)
            dbHelper.upsertIntake(scheduleId, today, true)
        }
        c.close()

        Toast.makeText(this, "복용 기록 완료", Toast.LENGTH_SHORT).show()
        finish()
    }

    // --------------------
    // 상단 메뉴
    // --------------------
    override fun onCreateOptionsMenu(menu: Menu): Boolean {
        menuInflater.inflate(R.menu.menu_pill_detail, menu)
        return true
    }

    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        return when (item.itemId) {
            android.R.id.home -> {
                finish()
                true
            }

            R.id.action_edit -> {
                val intent = Intent(this, AddMedicineActivity::class.java)
                intent.putExtra("medicine_id", medicineId)
                startActivity(intent)
                true
            }

            R.id.action_delete -> {
                showDeleteDialog()
                true
            }

            else -> super.onOptionsItemSelected(item)
        }
    }

    private fun showDeleteDialog() {
        MaterialAlertDialogBuilder(this)
            .setTitle("약 삭제")
            .setMessage("이 약을 삭제할까요?\n모든 복약 기록도 함께 삭제돼요.")
            .setNegativeButton("취소", null)
            .setPositiveButton("삭제") { _, _ ->
                deleteMedicine()
            }
            .show()
    }

    private fun deleteMedicine() {
        val db = dbHelper.writableDatabase

        db.execSQL(
            """
            DELETE FROM intake_log
            WHERE schedule_id IN (
                SELECT schedule_id FROM dose_schedule WHERE medicine_id = ?
            )
            """.trimIndent(),
            arrayOf(medicineId)
        )

        dbHelper.deleteMedicine(medicineId)
        Toast.makeText(this, "약이 삭제됐어요.", Toast.LENGTH_SHORT).show()
        finish()
    }

    // --------------------
    // UI 헬퍼
    // --------------------
    private fun setBoldLabel(tv: TextView, label: String, value: String) {
        val ssb = SpannableStringBuilder().apply {
            append(label)
            setSpan(
                StyleSpan(Typeface.BOLD),
                0,
                label.length,
                Spanned.SPAN_EXCLUSIVE_EXCLUSIVE
            )
            append(" ")
            append(value)
        }
        tv.setText(ssb, TextView.BufferType.SPANNABLE)
    }

    private fun setBoldLabelMultiline(tv: TextView, label: String, lines: String) {
        val ssb = SpannableStringBuilder().apply {
            append(label)
            setSpan(
                StyleSpan(Typeface.BOLD),
                0,
                label.length,
                Spanned.SPAN_EXCLUSIVE_EXCLUSIVE
            )
            append("\n")
            append(lines)
        }
        tv.setText(ssb, TextView.BufferType.SPANNABLE)
    }
}
