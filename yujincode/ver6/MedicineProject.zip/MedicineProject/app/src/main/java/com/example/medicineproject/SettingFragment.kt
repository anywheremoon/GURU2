package com.example.medicineproject

import android.app.AlertDialog
import android.os.Bundle
import android.view.View
import android.widget.Button
import android.widget.Switch
import android.widget.Toast
import androidx.fragment.app.Fragment
import com.example.medicineproject.db.DBHelper
import com.example.medicineproject.alarm.AlarmScheduler


class SettingsFragment : Fragment(R.layout.fragment_setting) {

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)


        val btnEnableAlarm = view.findViewById<Button>(R.id.btnEnableAlarm)
        val btnReset = view.findViewById<Button>(R.id.btnReset)
        val dbHelper = DBHelper(requireContext())


        btnEnableAlarm.setOnClickListener {
            AlarmScheduler.scheduleAll(requireContext())
            Toast.makeText(
                requireContext(),
                "복용 알림 설정 완료",
                Toast.LENGTH_SHORT
            ).show()
        }


        btnReset.setOnClickListener {
            AlertDialog.Builder(requireContext())
                .setTitle("데이터 초기화")
                .setMessage("모든 약 정보와 복용 기록이 삭제됩니다.\n정말 초기화할까요?")
                .setPositiveButton("초기화") { _, _ ->
                    dbHelper.clearAllData()
                    Toast.makeText(
                        requireContext(),
                        "모든 데이터가 초기화되었습니다",
                        Toast.LENGTH_SHORT
                    ).show()
                }
                .setNegativeButton("취소", null)
                .show()
        }
    }
}