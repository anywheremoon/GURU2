package com.example.medicineproject

import android.os.Bundle
import android.view.Menu
import android.view.MenuItem
import android.widget.Button
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import com.example.medicineproject.db.DBHelper
import java.text.SimpleDateFormat
import java.util.*
import androidx.appcompat.widget.Toolbar
import android.content.Intent


class PillDetailActivity : AppCompatActivity() {

    private lateinit var dbHelper: DBHelper
    private var medicineId: Long = -1L

    private val today: String by lazy {
        SimpleDateFormat("yyyy-MM-dd", Locale.KOREA).format(Date())
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_pill_detail)

        dbHelper = DBHelper(this)
        medicineId = intent.getLongExtra("medicine_id", -1L)

        if (medicineId == -1L) {
            finish()
            return
        }

        // ← 뒤로가기 표시
        supportActionBar?.setDisplayHomeAsUpEnabled(true)

        val tvCategory = findViewById<TextView>(R.id.tvCategory)
        val tvSchedules = findViewById<TextView>(R.id.tvSchedules)
        val tvLastTaken = findViewById<TextView>(R.id.tvLastTaken)
        val btnTake = findViewById<Button>(R.id.btnTake)

        val db = dbHelper.readableDatabase

        val toolbar = findViewById<Toolbar>(R.id.toolbar)
        setSupportActionBar(toolbar)


        // 1️⃣ 약 기본 정보
        val c1 = db.rawQuery(
            "SELECT name, category FROM medicine WHERE medicine_id = ?",
            arrayOf(medicineId.toString())
        )
        if (c1.moveToFirst()) {
            val name = c1.getString(0)
            tvCategory.text = "분류: ${c1.getString(1) ?: "-"}"

            // AppBar 제목도 약 이름으로
            supportActionBar?.title = name
        }
        c1.close()

        // 2️⃣ 스케줄 목록
        val sbSchedule = StringBuilder("복용 시간:\n")
        val c2 = db.rawQuery(
            """
            SELECT time_type, amount, unit
            FROM dose_schedule
            WHERE medicine_id = ?
            """.trimIndent(),
            arrayOf(medicineId.toString())
        )
        while (c2.moveToNext()) {
            sbSchedule.append(
                "- ${c2.getString(0)} : ${c2.getInt(1)}${c2.getString(2)}\n"
            )
        }
        c2.close()
        tvSchedules.text = sbSchedule.toString().trim()

        // 3️⃣ 마지막 복용 날짜
        val c3 = db.rawQuery(
            """
            SELECT MAX(date)
            FROM intake_log
            WHERE schedule_id IN (
                SELECT schedule_id FROM dose_schedule WHERE medicine_id = ?
            )
            """.trimIndent(),
            arrayOf(medicineId.toString())
        )
        tvLastTaken.text =
            if (c3.moveToFirst() && c3.getString(0) != null)
                "마지막 복용: ${c3.getString(0)}"
            else
                "아직 복용 기록 없어요"
        c3.close()

        // 4️⃣ 먹음 처리 버튼
        btnTake.setOnClickListener {
            val c4 = db.rawQuery(
                """
                SELECT COUNT(*)
                FROM intake_log
                WHERE date = ?
                AND schedule_id IN (
                    SELECT schedule_id FROM dose_schedule WHERE medicine_id = ?
                )
                """.trimIndent(),
                arrayOf(today, medicineId.toString())
            )

            val alreadyTaken = c4.moveToFirst() && c4.getInt(0) > 0
            c4.close()

            if (alreadyTaken) {
                AlertDialog.Builder(this)
                    .setTitle("중복 복용 경고")
                    .setMessage("오늘 이미 이 약을 복용했어요.\n그래도 다시 기록할까요?")
                    .setPositiveButton("그래도 기록") { _, _ ->
                        markTaken()
                    }
                    .setNegativeButton("취소", null)
                    .show()
            } else {
                markTaken()
            }
        }
    }

    // --------------------
    // 상단 메뉴 (삭제)
    // --------------------

    override fun onCreateOptionsMenu(menu: Menu): Boolean {
        menuInflater.inflate(R.menu.menu_pill_detail, menu)
        return true
    }

    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        return when (item.itemId) {
            android.R.id.home -> {
                finish()
                true
            }
            R.id.action_edit -> {
                val intent = Intent(this, AddMedicineActivity::class.java)
                intent.putExtra("medicine_id", medicineId)
                startActivity(intent)
                true
            }
            R.id.action_delete -> {
                showDeleteDialog()
                true
            }
            else -> super.onOptionsItemSelected(item)
        }
    }


    private fun showDeleteDialog() {
        AlertDialog.Builder(this)
            .setTitle("약 삭제")
            .setMessage("이 약을 삭제할까요?\n모든 복약 기록도 함께 삭제돼요.")
            .setNegativeButton("취소", null)
            .setPositiveButton("삭제") { _, _ ->
                deleteMedicine()
            }
            .show()
    }

    private fun deleteMedicine() {
        dbHelper.deleteMedicine(medicineId)
        Toast.makeText(this, "약이 삭제됐어요.", Toast.LENGTH_SHORT).show()
        finish()
    }

    // --------------------
    // 복용 기록
    // --------------------

    private fun markTaken() {
        val db = dbHelper.writableDatabase

        val c = db.rawQuery(
            "SELECT schedule_id FROM dose_schedule WHERE medicine_id = ?",
            arrayOf(medicineId.toString())
        )

        while (c.moveToNext()) {
            val scheduleId = c.getInt(0)
            dbHelper.upsertIntake(scheduleId, today, true)
        }
        c.close()

        Toast.makeText(this, "복용 기록 완료", Toast.LENGTH_SHORT).show()
        finish()
    }
}
