package com.example.medicineproject

import android.content.Intent
import android.os.Bundle
import android.view.View
import android.widget.TextView
import androidx.fragment.app.Fragment
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.example.medicineproject.adapter.MedicineAdapter
import com.example.medicineproject.adapter.MedicineItem
import com.example.medicineproject.db.DBHelper
import com.google.android.material.floatingactionbutton.FloatingActionButton


class MedicineFragment : Fragment(R.layout.fragment_medicine) {

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        val recycler = view.findViewById<RecyclerView>(R.id.recyclerMedicine)
        val tvEmpty = view.findViewById<TextView>(R.id.tvEmpty)

        recycler.layoutManager = LinearLayoutManager(requireContext())

        val db = DBHelper(requireContext()).readableDatabase
        val list = mutableListOf<MedicineItem>()

        val cursor = db.rawQuery(
            "SELECT medicine_id, name, category FROM medicine ORDER BY medicine_id DESC",
            null
        )

        while (cursor.moveToNext()) {
            list.add(
                MedicineItem(
                    id = cursor.getLong(0),
                    name = cursor.getString(1),
                    category = cursor.getString(2)
                )
            )
        }
        cursor.close()

        if (list.isEmpty()) {
            tvEmpty.visibility = View.VISIBLE
            recycler.visibility = View.GONE
        } else {
            tvEmpty.visibility = View.GONE
            recycler.visibility = View.VISIBLE
            recycler.adapter = MedicineAdapter(list)
        }

        val fab = view.findViewById<FloatingActionButton>(R.id.fabAddMedicine)
        fab.setOnClickListener {
            startActivity(Intent(requireContext(), AddMedicineActivity::class.java))
        }

    }
}
