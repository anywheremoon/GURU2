package com.example.medicineproject.adapter

import android.content.Intent
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import com.example.medicineproject.PillDetailActivity
import com.example.medicineproject.R

data class MedicineItem(
    val id: Long,
    val name: String,
    val category: String?
)

class MedicineAdapter(
    private val items: List<MedicineItem>
) : RecyclerView.Adapter<MedicineAdapter.ViewHolder>() {

    class ViewHolder(view: View) : RecyclerView.ViewHolder(view) {
        val tvName: TextView = view.findViewById(R.id.tvName)
        val tvCategory: TextView = view.findViewById(R.id.tvCategory)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
        val view = LayoutInflater.from(parent.context)
            .inflate(R.layout.item_medicine, parent, false)
        return ViewHolder(view)
    }

    override fun getItemCount(): Int = items.size

    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        val item = items[position]

        holder.tvName.text = item.name
        holder.tvCategory.text = item.category ?: "-"

        holder.itemView.setOnClickListener {
            val context = holder.itemView.context
            val intent = Intent(context, PillDetailActivity::class.java)
            intent.putExtra("medicine_id", item.id)
            context.startActivity(intent)
        }
    }
}
