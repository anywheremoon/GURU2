package com.example.medicineproject

import android.graphics.Color
import android.os.Bundle
import android.view.View
import android.widget.TextView
import androidx.fragment.app.Fragment
import com.example.medicineproject.calendar.ColorDecorator
import com.example.medicineproject.db.DBHelper
import com.prolificinteractive.materialcalendarview.CalendarDay
import com.prolificinteractive.materialcalendarview.MaterialCalendarView
import java.text.SimpleDateFormat
import java.util.*

class CalendarFragment : Fragment(R.layout.fragment_calendar) {

    private val dateFormat = SimpleDateFormat("yyyy-MM-dd", Locale.KOREA)

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {

        val calendarView = view.findViewById<MaterialCalendarView>(R.id.calendarView)
        val tvStatus = view.findViewById<TextView>(R.id.tvStatus)
        val tvDetail = view.findViewById<TextView>(R.id.tvDetail)

        val db = DBHelper(requireContext()).readableDatabase

        /**
         * 🔹 달력 색칠 (스케줄 기준)
         */
        fun refreshCalendar(year: Int, month: Int) {
            val completeDates = mutableListOf<CalendarDay>()
            val partialDates = mutableListOf<CalendarDay>()
            val failDates = mutableListOf<CalendarDay>()

            val cal = Calendar.getInstance()
            cal.set(year, month - 1, 1)
            val daysInMonth = cal.getActualMaximum(Calendar.DAY_OF_MONTH)

            for (day in 1..daysInMonth) {
                cal.set(year, month - 1, day)
                val dateStr = dateFormat.format(cal.time)

                val cursor = db.rawQuery(
                    """
        SELECT 
            COUNT(*) as total,
            SUM(CASE WHEN i.taken = 1 THEN 1 ELSE 0 END) as taken_count
        FROM dose_schedule d
        LEFT JOIN intake_log i 
          ON i.schedule_id = d.schedule_id 
          AND i.date = ?
        WHERE ? BETWEEN d.start_date AND d.end_date
        """.trimIndent(),
                    arrayOf(dateStr, dateStr)
                )

                if (!cursor.moveToFirst()) {
                    cursor.close()
                    continue
                }

                val total = cursor.getInt(0)
                val taken = cursor.getInt(1)
                cursor.close()

                if (total == 0) continue

                val calendarDay = CalendarDay.from(year, month, day)  // 🔥 여기 수정!

                when {
                    taken == total -> completeDates.add(calendarDay)
                    taken == 0 -> failDates.add(calendarDay)
                    else -> partialDates.add(calendarDay)
                }
            }

// 🔍 최종 결과 로그
            android.util.Log.d("CalendarDebug", "초록: ${completeDates.size}, 노랑: ${partialDates.size}, 빨강: ${failDates.size}")

            calendarView.removeDecorators()
            calendarView.addDecorator(ColorDecorator(Color.GREEN, completeDates))
            calendarView.addDecorator(ColorDecorator(Color.rgb(255, 165, 0), partialDates))
            calendarView.addDecorator(ColorDecorator(Color.RED, failDates))
        }

        // 🔹 최초 로딩
        val today = Calendar.getInstance()
        refreshCalendar(today.get(Calendar.YEAR), today.get(Calendar.MONTH) + 1)

        // 🔹 월 이동 시 다시 계산
        calendarView.setOnMonthChangedListener { _, date ->
            refreshCalendar(date.year, date.month)
        }

        /**
         * 🔹 날짜 클릭 시 상세 표시
         */
        calendarView.setOnDateChangedListener { _, date, _ ->

            val selectedDate = String.format(
                "%04d-%02d-%02d",
                date.year,
                date.month + 1,
                date.day
            )

            val cursor = db.rawQuery(
                """
                SELECT d.time_type, m.name, COALESCE(i.taken, 0)
                FROM dose_schedule d
                JOIN medicine m ON d.medicine_id = m.medicine_id
                LEFT JOIN intake_log i
                  ON i.schedule_id = d.schedule_id
                 AND i.date = ?
                WHERE ? BETWEEN d.start_date AND d.end_date
                ORDER BY
                    CASE d.time_type
                        WHEN '아침' THEN 1
                        WHEN '점심' THEN 2
                        WHEN '저녁' THEN 3
                        WHEN '취침 전' THEN 4
                        ELSE 99
                    END
                """.trimIndent(),
                arrayOf(selectedDate, selectedDate)
            )

            val grouped = linkedMapOf<String, MutableList<Pair<String, Boolean>>>()

            while (cursor.moveToNext()) {
                val timeType = cursor.getString(0)
                val name = cursor.getString(1)
                val taken = cursor.getInt(2) == 1

                grouped.getOrPut(timeType) { mutableListOf() }
                    .add(name to taken)
            }
            cursor.close()

            val sb = StringBuilder()
            for (time in listOf("아침", "점심", "저녁", "취침 전")) {
                val list = grouped[time] ?: continue
                sb.append("$time\n")
                for ((name, taken) in list) {
                    sb.append("   ${if (taken) "✅" else "❌"} $name\n")
                }
                sb.append("\n")
            }

            tvStatus.text = selectedDate
            tvDetail.text = if (sb.isNotEmpty()) sb.toString().trim() else "기록이 없어."
        }
    }
}
