package com.example.medicineproject

import android.graphics.Color
import android.os.Bundle
import android.view.View
import android.widget.LinearLayout
import android.widget.TextView
import androidx.fragment.app.Fragment
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.example.medicineproject.adapter.DoseSetAdapter
import com.example.medicineproject.db.DBHelper
import com.example.medicineproject.model.DoseSet
import java.text.SimpleDateFormat
import java.util.*

class TodayFragment : Fragment(R.layout.fragment_today) {

    private lateinit var dbHelper: DBHelper
    private lateinit var tvTodayDate: TextView
    private lateinit var containerTodayCheck: LinearLayout
    private lateinit var recyclerDoseSet: RecyclerView

    // DB 기준 포맷: yyyy-MM-dd
    private val dbDateFormat = SimpleDateFormat("yyyy-MM-dd", Locale.KOREA)
    // 화면 표시용 포맷
    private val uiDateFormat = SimpleDateFormat("yyyy년 M월 d일 (E)", Locale.KOREA)

    private lateinit var today: String
    private var doseSets: List<DoseSet> = emptyList()

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        dbHelper = DBHelper(requireContext())

        tvTodayDate = view.findViewById(R.id.tvTodayDate)
        containerTodayCheck = view.findViewById(R.id.containerTodayCheck)
        recyclerDoseSet = view.findViewById(R.id.recyclerDoseSet)

        val now = Date()
        today = dbDateFormat.format(now)
        tvTodayDate.text = uiDateFormat.format(now)

        recyclerDoseSet.layoutManager = LinearLayoutManager(requireContext())

        // 1) 오늘 데이터 로드
        loadToday()
    }

    private fun loadToday() {
        doseSets = dbHelper.getTodayDoseSets(today)

        // 2) RecyclerView 연결
        recyclerDoseSet.adapter = DoseSetAdapter(
            items = doseSets,
            dbHelper = dbHelper,
            date = today
        ) {
            // 체크 변경될 때마다 상단 요약만 다시 그림 (DB까지는 이미 저장됨)
            renderTopSummary(doseSets)
        }

        // 3) 상단 요약 출력
        renderTopSummary(doseSets)
    }

    private fun renderTopSummary(doseSets: List<DoseSet>) {
        containerTodayCheck.removeAllViews()

        // “오늘 먹어야 할 약” 요약: 체크된 건 회색 처리
        for (set in doseSets) {
            if (set.items.isEmpty()) continue

            val title = TextView(requireContext()).apply {
                text = "• ${set.timeType}"
                setTextColor(Color.DKGRAY)
                textSize = 16f
            }
            containerTodayCheck.addView(title)

            for (item in set.items) {
                val line = TextView(requireContext()).apply {
                    text = "   - ${item.name} ${item.amount}${item.unit}"
                    setTextColor(if (item.taken) Color.GRAY else Color.BLACK)
                    textSize = 15f
                }
                containerTodayCheck.addView(line)
            }
        }

        // 아무 스케줄도 없으면 안내 문구
        if (doseSets.isEmpty()) {
            val empty = TextView(requireContext()).apply {
                text = "오늘 복용할 약이 없어요!"
                setTextColor(Color.GRAY)
                textSize = 15f
            }
            containerTodayCheck.addView(empty)
        }
    }
}
