package com.example.medicineproject

import android.app.DatePickerDialog
import android.content.Intent
import android.graphics.Color
import android.os.Bundle
import android.view.View
import android.widget.LinearLayout
import android.widget.TextView
import androidx.fragment.app.Fragment
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.example.medicineproject.adapter.DoseSetAdapter
import com.example.medicineproject.alarm.AlarmScheduler
import com.example.medicineproject.db.DBHelper
import com.example.medicineproject.model.DoseSet
import com.google.android.material.floatingactionbutton.FloatingActionButton
import java.text.SimpleDateFormat
import java.util.*

class TodayFragment : Fragment(R.layout.fragment_today) {

    private lateinit var dbHelper: DBHelper
    private lateinit var tvTodayDate: TextView
    private lateinit var containerTodayCheck: LinearLayout
    private lateinit var recyclerDoseSet: RecyclerView
    private lateinit var fabAddMedicine: FloatingActionButton   // ✅ 추가

    private val dbDateFormat = SimpleDateFormat("yyyy-MM-dd", Locale.KOREA)
    private val uiDateFormat = SimpleDateFormat("yyyy년 M월 d일 (E)", Locale.KOREA)

    private val selectedCal: Calendar = Calendar.getInstance()
    private lateinit var today: String
    private var doseSets: List<DoseSet> = emptyList()

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        dbHelper = DBHelper(requireContext())

        tvTodayDate = view.findViewById(R.id.tvTodayDate)
        containerTodayCheck = view.findViewById(R.id.containerTodayCheck)
        recyclerDoseSet = view.findViewById(R.id.recyclerDoseSet)
        fabAddMedicine = view.findViewById(R.id.fabAddMedicine) // ✅ 여기

        recyclerDoseSet.layoutManager = LinearLayoutManager(requireContext())

        // ✅ FAB 클릭 → 약 추가
        fabAddMedicine.setOnClickListener {
            startActivity(Intent(requireContext(), AddMedicineActivity::class.java))
        }

        syncDateAndReload()

        tvTodayDate.setOnClickListener {
            openDatePicker()
        }
    }

    override fun onResume() {
        super.onResume()
        syncDateAndReload()   // ⭐ 약 추가/삭제 즉각 반영
        AlarmScheduler.rescheduleToday(requireContext())
    }

    private fun openDatePicker() {
        val y = selectedCal.get(Calendar.YEAR)
        val m = selectedCal.get(Calendar.MONTH)
        val d = selectedCal.get(Calendar.DAY_OF_MONTH)

        DatePickerDialog(
            requireContext(),
            { _, year, month, dayOfMonth ->
                selectedCal.set(year, month, dayOfMonth)
                syncDateAndReload()
            },
            y, m, d
        ).show()
    }

    private fun syncDateAndReload() {
        val dateObj = selectedCal.time
        today = dbDateFormat.format(dateObj)
        tvTodayDate.text = uiDateFormat.format(dateObj)
        loadByDate(today)
    }

    private fun loadByDate(date: String) {
        doseSets = dbHelper.getTodayDoseSets(date)

        recyclerDoseSet.adapter = DoseSetAdapter(
            items = doseSets,
            dbHelper = dbHelper,
            date = date
        ) {
            renderTopSummary(doseSets)
        }

        renderTopSummary(doseSets)
    }

    private fun renderTopSummary(doseSets: List<DoseSet>) {
        containerTodayCheck.removeAllViews()

        for (set in doseSets) {
            if (set.items.isEmpty()) continue

            val title = TextView(requireContext()).apply {
                text = "• ${set.timeType}"
                setTextColor(Color.DKGRAY)
                textSize = 16f
            }
            containerTodayCheck.addView(title)

            for (item in set.items) {
                val line = TextView(requireContext()).apply {
                    text = "   - ${item.name} ${item.amount}${item.unit}"
                    setTextColor(if (item.taken) Color.GRAY else Color.BLACK)
                    textSize = 15f
                }
                containerTodayCheck.addView(line)
            }
        }

        if (doseSets.isEmpty()) {
            val empty = TextView(requireContext()).apply {
                text = "복용할 약이 없어요!"
                setTextColor(Color.GRAY)
                textSize = 15f
            }
            containerTodayCheck.addView(empty)
        }
    }
}
