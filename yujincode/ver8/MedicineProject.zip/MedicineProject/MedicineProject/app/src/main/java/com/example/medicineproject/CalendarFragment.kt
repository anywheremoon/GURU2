package com.example.medicineproject

import android.content.Intent
import android.graphics.Color
import android.os.Bundle
import android.view.View
import android.widget.TextView
import androidx.fragment.app.Fragment
import com.example.medicineproject.calendar.ColorDecorator
import com.example.medicineproject.db.DBHelper
import com.google.android.material.floatingactionbutton.FloatingActionButton
import com.prolificinteractive.materialcalendarview.CalendarDay
import com.prolificinteractive.materialcalendarview.MaterialCalendarView
import java.text.SimpleDateFormat
import java.util.*

class CalendarFragment : Fragment(R.layout.fragment_calendar) {

    private lateinit var calendarView: MaterialCalendarView
    private lateinit var dbHelper: DBHelper

    private val sdf = SimpleDateFormat("yyyy-MM-dd", Locale.KOREA)



    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        view.findViewById<FloatingActionButton>(R.id.fabAddMedicine)
            .setOnClickListener {
                startActivity(Intent(requireContext(), AddMedicineActivity::class.java))
            }


        calendarView = view.findViewById(R.id.calendarView)
        val tvStatus = view.findViewById<TextView>(R.id.tvStatus)
        val tvDetail = view.findViewById<TextView>(R.id.tvDetail)

        dbHelper = DBHelper(requireContext())

        val today = CalendarDay.today()
        refreshCalendar(today.year, today.month)

        calendarView.setOnMonthChangedListener { _, date ->
            refreshCalendar(date.year, date.month)
        }

        calendarView.setOnDateChangedListener { _, date, _ ->
            showDateDetail(date, tvStatus, tvDetail)
        }

        calendarView.setSelectedDate(today)
        showDateDetail(today, tvStatus, tvDetail)
    }

    override fun onResume() {
        super.onResume()
        val today = CalendarDay.today()
        refreshCalendar(today.year, today.month)
    }

    /**
     * ✅ 색상 판정 로직 (이제 헷갈릴 여지 없음)
     */
    private fun refreshCalendar(year: Int, month: Int) {
        val green = mutableListOf<CalendarDay>()
        val yellow = mutableListOf<CalendarDay>()
        val red = mutableListOf<CalendarDay>()

        val cal = Calendar.getInstance()
        cal.set(year, month, 1)

        val today = Calendar.getInstance()
        val maxDay = cal.getActualMaximum(Calendar.DAY_OF_MONTH)

        for (day in 1..maxDay) {
            cal.set(year, month, day)
            val dateStr = sdf.format(cal.time)
            val calendarDay = CalendarDay.from(year, month, day)

            // 🔴 미래 날짜 → 빨강
            if (cal.after(today)) {
                red.add(calendarDay)
                continue
            }

            val status = dbHelper.getDayIntakeStatus(dateStr)

            // ❌ 스케줄 없음 → 아무 색도 안 칠함
            if (status.total == 0) continue

            when {
                // 🟢 전부 복용
                status.taken == status.total ->
                    green.add(calendarDay)

                // 🔴 하나도 안 먹음
                status.taken == 0 ->
                    red.add(calendarDay)

                // 🟡 일부만 먹음
                else ->
                    yellow.add(calendarDay)
            }
        }

        calendarView.removeDecorators()
        calendarView.addDecorator(ColorDecorator(Color.GREEN, green))
        calendarView.addDecorator(ColorDecorator(Color.rgb(255, 165, 0), yellow))
        calendarView.addDecorator(ColorDecorator(Color.RED, red))
    }

    /**
     * 날짜 상세 표시 (기존 로직 유지)
     */
    private fun showDateDetail(
        date: CalendarDay,
        tvStatus: TextView,
        tvDetail: TextView
    ) {
        val dateStr = String.format(
            "%04d-%02d-%02d",
            date.year,
            date.month + 1,
            date.day
        )

        val db = dbHelper.readableDatabase
        val cursor = db.rawQuery(
            """
            SELECT d.time_type, m.name, COALESCE(i.taken, 0)
            FROM dose_schedule d
            JOIN medicine m ON d.medicine_id = m.medicine_id
            LEFT JOIN intake_log i
              ON i.schedule_id = d.schedule_id
             AND i.date = ?
            WHERE ? BETWEEN d.start_date AND d.end_date
            ORDER BY
                CASE d.time_type
                    WHEN '아침' THEN 1
                    WHEN '점심' THEN 2
                    WHEN '저녁' THEN 3
                    WHEN '취침 전' THEN 4
                    ELSE 99
                END
            """.trimIndent(),
            arrayOf(dateStr, dateStr)
        )

        val grouped = linkedMapOf<String, MutableList<Pair<String, Boolean>>>()

        while (cursor.moveToNext()) {
            val timeType = cursor.getString(0)
            val name = cursor.getString(1)
            val taken = cursor.getInt(2) == 1

            grouped.getOrPut(timeType) { mutableListOf() }
                .add(name to taken)
        }
        cursor.close()

        val sb = StringBuilder()
        for (time in listOf("아침", "점심", "저녁", "취침 전")) {
            val list = grouped[time] ?: continue
            sb.append("$time\n")
            for ((name, taken) in list) {
                sb.append("   ${if (taken) "✅" else "❌"} $name\n")
            }
            sb.append("\n")
        }



        tvStatus.text = dateStr
        tvDetail.text = if (sb.isNotEmpty()) sb.toString().trim() else "기록이 없어요."
    }




}
