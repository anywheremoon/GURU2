package com.example.medicineproject.adapter

import android.content.Intent
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.CheckBox
import android.widget.LinearLayout
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import com.example.medicineproject.PillDetailActivity
import com.example.medicineproject.R
import com.example.medicineproject.alarm.AlarmScheduler
import com.example.medicineproject.db.DBHelper
import com.example.medicineproject.model.DoseSet

class DoseSetAdapter(
    private val items: List<DoseSet>,
    private val dbHelper: DBHelper,
    private val date: String,                 // "yyyy-MM-dd"
    private val onChanged: (() -> Unit)? = null
) : RecyclerView.Adapter<DoseSetAdapter.ViewHolder>() {

    class ViewHolder(view: View) : RecyclerView.ViewHolder(view) {
        val tvTimeType: TextView = view.findViewById(R.id.tvTimeType)
        val container: LinearLayout = view.findViewById(R.id.containerMedicines)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
        val view = LayoutInflater.from(parent.context)
            .inflate(R.layout.item_dose_set, parent, false)
        return ViewHolder(view)
    }

    override fun getItemCount(): Int = items.size

    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        val doseSet = items[position]
        val context = holder.itemView.context

        // 시간대 제목
        holder.tvTimeType.text = when (doseSet.timeType) {
            "아침" -> "🌅 아침 복용 세트"
            "점심" -> "🌞 점심 복용 세트"
            "저녁" -> "🌙 저녁 복용 세트"
            "취침 전" -> "🌜 취침 전 복용 세트"
            else -> doseSet.timeType
        }

        holder.container.removeAllViews()

        for (item in doseSet.items) {
            val row = LayoutInflater.from(context)
                .inflate(R.layout.item_dose_item, holder.container, false)

            val tvMedicine = row.findViewById<TextView>(R.id.tvMedicineInfo)
            val checkBox = row.findViewById<CheckBox>(R.id.checkTaken)

            tvMedicine.text = "- ${item.name} ${item.amount}${item.unit}"

            // ▶ 약 상세 화면 이동
            row.setOnClickListener {
                val intent = Intent(context, PillDetailActivity::class.java)
                intent.putExtra("medicine_id", item.medicineId)
                context.startActivity(intent)
            }

            // 체크 상태 세팅
            checkBox.setOnCheckedChangeListener(null)
            checkBox.isChecked = item.taken

            checkBox.setOnCheckedChangeListener { _, isChecked ->
                item.taken = isChecked
                dbHelper.upsertIntake(item.scheduleId, date, isChecked)

                // 🔥 핵심 로직
                if (isChecked) {
                    // 해당 시간대 전부 먹었으면 → 즉시 알람 취소
                    if (dbHelper.isTimeTypeCompleted(date, doseSet.timeType)) {
                        val requestCode = when (doseSet.timeType) {
                            "아침" -> 100
                            "점심" -> 101
                            "저녁" -> 102
                            "취침 전" -> 103
                            else -> null
                        }

                        requestCode?.let {
                            AlarmScheduler.cancel(context, it)
                        }
                    }
                }

                // 상태 변경 → TodayFragment에서 전체 알람 재정렬
                onChanged?.invoke()
            }

            holder.container.addView(row)
        }
    }
}
