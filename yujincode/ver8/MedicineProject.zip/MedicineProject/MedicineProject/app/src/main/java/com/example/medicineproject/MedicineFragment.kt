package com.example.medicineproject

import android.content.Intent
import android.os.Bundle
import android.view.View
import android.widget.TextView
import androidx.fragment.app.Fragment
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.example.medicineproject.adapter.MedicineAdapter
import com.example.medicineproject.adapter.MedicineItem
import com.example.medicineproject.db.DBHelper
import com.google.android.material.floatingactionbutton.FloatingActionButton

class MedicineFragment : Fragment(R.layout.fragment_medicine) {

    private lateinit var recycler: RecyclerView
    private lateinit var tvEmpty: TextView
    private lateinit var adapter: MedicineAdapter

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        recycler = view.findViewById(R.id.recyclerMedicine)
        tvEmpty = view.findViewById(R.id.tvEmpty)

        recycler.layoutManager = LinearLayoutManager(requireContext())
        adapter = MedicineAdapter(mutableListOf())
        recycler.adapter = adapter

        loadMedicines()

        view.findViewById<FloatingActionButton>(R.id.fabAddMedicine).setOnClickListener {
            startActivity(Intent(requireContext(), AddMedicineActivity::class.java))
        }

        view.findViewById<FloatingActionButton>(R.id.fabSupplementRecommend).setOnClickListener {
            parentFragmentManager.beginTransaction()
                .replace(R.id.container, SupplementCombinationFragment())
                .addToBackStack(null)
                .commit()
        }
    }

    override fun onResume() {
        super.onResume()
        loadMedicines() // ✅ 삭제/추가 후 즉각 반영
    }

    private fun loadMedicines() {
        val db = DBHelper(requireContext()).readableDatabase
        val list = mutableListOf<MedicineItem>()

        val cursor = db.rawQuery(
            "SELECT medicine_id, name, category, photo_uri FROM medicine ORDER BY medicine_id DESC",
            null
        )

        while (cursor.moveToNext()) {
            list.add(
                MedicineItem(
                    id = cursor.getLong(0),
                    name = cursor.getString(1),
                    category = cursor.getString(2),
                    photoUri = cursor.getString(3)
                )
            )
        }
        cursor.close()

        if (list.isEmpty()) {
            tvEmpty.visibility = View.VISIBLE
            recycler.visibility = View.GONE
        } else {
            tvEmpty.visibility = View.GONE
            recycler.visibility = View.VISIBLE
            adapter.updateItems(list)
        }
    }
}
