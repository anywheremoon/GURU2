package com.example.medicineproject.db

import android.content.ContentValues
import android.content.Context
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteOpenHelper
import com.example.medicineproject.model.DoseItem
import com.example.medicineproject.model.DoseSet
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale

class DBHelper(context: Context) : SQLiteOpenHelper(
    context,
    DB_NAME,
    null,
    DB_VERSION
) {

    // ✅ 외래키/캐스케이드 삭제가 동작하려면 매번 켜야 함
    override fun onConfigure(db: SQLiteDatabase) {
        super.onConfigure(db)
        db.setForeignKeyConstraintsEnabled(true)
        // 또는 아래 둘 중 하나(안드 버전 호환용):
        // db.execSQL("PRAGMA foreign_keys=ON")
    }

    override fun onCreate(db: SQLiteDatabase) {
        db.execSQL(
            """
            CREATE TABLE IF NOT EXISTS medicine (
                medicine_id INTEGER PRIMARY KEY AUTOINCREMENT,
                name TEXT NOT NULL,
                category TEXT,
                photo_uri TEXT
            )
            """.trimIndent()
        )

        db.execSQL(
            """
            CREATE TABLE IF NOT EXISTS dose_schedule (
                schedule_id INTEGER PRIMARY KEY AUTOINCREMENT,
                medicine_id INTEGER NOT NULL,
                time_type TEXT NOT NULL,
                amount INTEGER NOT NULL,
                unit TEXT NOT NULL,
                start_date TEXT NOT NULL,
                end_date TEXT NOT NULL,
                FOREIGN KEY(medicine_id) REFERENCES medicine(medicine_id) ON DELETE CASCADE
            )
            """.trimIndent()
        )

        db.execSQL(
            """
            CREATE TABLE IF NOT EXISTS intake_log (
                log_id INTEGER PRIMARY KEY AUTOINCREMENT,
                schedule_id INTEGER NOT NULL,
                date TEXT NOT NULL,
                taken INTEGER NOT NULL DEFAULT 0,
                UNIQUE(schedule_id, date),
                FOREIGN KEY(schedule_id) REFERENCES dose_schedule(schedule_id) ON DELETE CASCADE
            )
            """.trimIndent()
        )

        // 조회 성능용 인덱스
        db.execSQL("CREATE INDEX IF NOT EXISTS idx_schedule_medicine ON dose_schedule(medicine_id)")
        db.execSQL("CREATE INDEX IF NOT EXISTS idx_schedule_date_range ON dose_schedule(start_date, end_date)")
        db.execSQL("CREATE INDEX IF NOT EXISTS idx_intake_date ON intake_log(date)")
        db.execSQL("CREATE INDEX IF NOT EXISTS idx_intake_schedule_date ON intake_log(schedule_id, date)")
    }

    override fun onUpgrade(db: SQLiteDatabase, oldVersion: Int, newVersion: Int) {
        db.execSQL("DROP TABLE IF EXISTS intake_log")
        db.execSQL("DROP TABLE IF EXISTS dose_schedule")
        db.execSQL("DROP TABLE IF EXISTS medicine")
        onCreate(db)
    }

    /**
     * date: "yyyy-MM-dd"
     * 해당 날짜에 해당하는 복약 스케줄을 시간대별로 묶어서 반환
     */
    fun getTodayDoseSets(date: String): List<DoseSet> {
        val db = readableDatabase

        val sql = """
        SELECT 
            s.schedule_id,
            s.time_type,
            m.medicine_id,
            m.name,
            s.amount,
            s.unit,
            COALESCE(l.taken, 0) AS taken
        FROM dose_schedule s
        JOIN medicine m ON m.medicine_id = s.medicine_id
        LEFT JOIN intake_log l 
            ON l.schedule_id = s.schedule_id AND l.date = ?
        WHERE ? BETWEEN s.start_date AND s.end_date
        ORDER BY 
            CASE s.time_type
                WHEN '아침' THEN 1
                WHEN '점심' THEN 2
                WHEN '저녁' THEN 3
                WHEN '취침 전' THEN 4
                ELSE 99
            END,
            s.schedule_id ASC
        """.trimIndent()

        val cursor = db.rawQuery(sql, arrayOf(date, date))

        val map = linkedMapOf<String, MutableList<DoseItem>>()

        while (cursor.moveToNext()) {
            val scheduleId = cursor.getInt(0)
            val timeType = cursor.getString(1)
            val medicineId = cursor.getLong(2)
            val name = cursor.getString(3)
            val amount = cursor.getInt(4)
            val unit = cursor.getString(5)
            val taken = cursor.getInt(6) == 1

            val item = DoseItem(
                scheduleId = scheduleId,
                medicineId = medicineId,
                name = name,
                amount = amount,
                unit = unit,
                taken = taken
            )

            val list = map.getOrPut(timeType) { mutableListOf() }
            list.add(item)
        }

        cursor.close()

        return map.entries.map { (timeType, items) ->
            DoseSet(timeType = timeType, items = items)
        }
    }

    /**
     * 체크박스/먹음 처리 시: 해당 날짜(scheduleId, date) 기록을 INSERT 또는 UPDATE
     */
    fun upsertIntake(scheduleId: Int, date: String, taken: Boolean) {
        val db = writableDatabase
        val takenInt = if (taken) 1 else 0

        db.execSQL(
            """
            INSERT OR REPLACE INTO intake_log (schedule_id, date, taken)
            VALUES (?, ?, ?)
            """.trimIndent(),
            arrayOf(scheduleId, date, takenInt)
        )
    }

    fun insertMedicine(name: String, category: String?, photoUri: String? = null): Long {
        val db = writableDatabase
        db.execSQL(
            """
            INSERT INTO medicine (name, category, photo_uri)
            VALUES (?, ?, ?)
            """.trimIndent(),
            arrayOf(name, category, photoUri)
        )

        val cursor = db.rawQuery("SELECT last_insert_rowid()", null)
        cursor.moveToFirst()
        val id = cursor.getLong(0)
        cursor.close()
        return id
    }

    fun insertDoseSchedule(
        medicineId: Long,
        timeType: String,
        amount: Int,
        unit: String,
        startDate: String,
        endDate: String
    ) {
        val db = writableDatabase
        db.execSQL(
            """
            INSERT INTO dose_schedule (medicine_id, time_type, amount, unit, start_date, end_date)
            VALUES (?, ?, ?, ?, ?, ?)
            """.trimIndent(),
            arrayOf(medicineId, timeType, amount, unit, startDate, endDate)
        )
    }

    fun deleteMedicine(medicineId: Long) {
        val db = writableDatabase
        // ✅ medicine 삭제만 해도 schedule/log가 CASCADE로 같이 삭제되어야 함 (foreign_keys ON 필요)
        db.delete(
            "medicine",
            "medicine_id = ?",
            arrayOf(medicineId.toString())
        )
        // ✅ 혹시 과거에 foreign_keys OFF로 생긴 고아 log가 있으면 정리(안전장치)
        cleanupOrphanLogs()
    }

    fun updateMedicine(
        medicineId: Long,
        name: String,
        category: String,
        photoUri: String?
    ) {
        val db = writableDatabase
        val values = ContentValues().apply {
            put("name", name)
            put("category", category)
            put("photo_uri", photoUri)
        }

        db.update(
            "medicine",
            values,
            "medicine_id = ?",
            arrayOf(medicineId.toString())
        )
    }

    data class StatsSummary(
        val total: Int,
        val done: Int,
        val missed: Int
    )

    // ✅ 달력/통계에 “삭제된 약 기록이 남는 문제”를 막기 위해
    //    done 집계는 반드시 dose_schedule + medicine을 기준으로 JOIN
    fun getMonthlySummary(month: String): StatsSummary {
        val db = readableDatabase

        val start = "$month-01"
        val end = "$month-31"

        val total = db.rawQuery(
            """
            SELECT COALESCE(SUM(
                JULIANDAY(MIN(ds.end_date, ?)) -
                JULIANDAY(MAX(ds.start_date, ?)) + 1
            ), 0)
            FROM dose_schedule ds
            JOIN medicine m ON ds.medicine_id = m.medicine_id
            WHERE ds.start_date <= ?
              AND ds.end_date >= ?
            """.trimIndent(),
            arrayOf(end, start, end, start)
        ).use { c ->
            if (c.moveToFirst()) c.getInt(0) else 0
        }

        val done = db.rawQuery(
            """
            SELECT COALESCE(COUNT(*), 0)
            FROM intake_log il
            JOIN dose_schedule ds ON il.schedule_id = ds.schedule_id
            JOIN medicine m ON ds.medicine_id = m.medicine_id
            WHERE il.taken = 1
              AND il.date BETWEEN ? AND ?
            """.trimIndent(),
            arrayOf(start, end)
        ).use { c ->
            if (c.moveToFirst()) c.getInt(0) else 0
        }

        val missed = (total - done).coerceAtLeast(0)
        return StatsSummary(total, done, missed)
    }

    fun getWeeklySummary(days: Int): StatsSummary {
        val db = readableDatabase

        val end = SimpleDateFormat("yyyy-MM-dd", Locale.getDefault()).format(Date())
        val cal = Calendar.getInstance().apply { add(Calendar.DAY_OF_MONTH, -days + 1) }
        val start = SimpleDateFormat("yyyy-MM-dd", Locale.getDefault()).format(cal.time)

        val total = db.rawQuery(
            """
            SELECT COALESCE(SUM(
                JULIANDAY(MIN(ds.end_date, ?)) -
                JULIANDAY(MAX(ds.start_date, ?)) + 1
            ), 0)
            FROM dose_schedule ds
            JOIN medicine m ON ds.medicine_id = m.medicine_id
            WHERE ds.start_date <= ?
              AND ds.end_date >= ?
            """.trimIndent(),
            arrayOf(end, start, end, start)
        ).use { c ->
            if (c.moveToFirst()) c.getInt(0) else 0
        }

        val done = db.rawQuery(
            """
            SELECT COALESCE(COUNT(*), 0)
            FROM intake_log il
            JOIN dose_schedule ds ON il.schedule_id = ds.schedule_id
            JOIN medicine m ON ds.medicine_id = m.medicine_id
            WHERE il.taken = 1
              AND il.date BETWEEN ? AND ?
            """.trimIndent(),
            arrayOf(start, end)
        ).use { c ->
            if (c.moveToFirst()) c.getInt(0) else 0
        }

        val missed = (total - done).coerceAtLeast(0)
        return StatsSummary(total, done, missed)
    }

    fun calcRatePercent(summary: StatsSummary): Int {
        if (summary.total == 0) return 0
        return (summary.done * 100) / summary.total
    }

    fun clearAllData() {
        val db = writableDatabase
        // ✅ 외래키 순서(log → schedule → medicine)
        db.execSQL("DELETE FROM intake_log")
        db.execSQL("DELETE FROM dose_schedule")
        db.execSQL("DELETE FROM medicine")
        // ✅ 혹시 남을 수 있는 고아 log 정리
        cleanupOrphanLogs()
    }

    /**
     * 오늘 복용해야 하는 time_type 목록 반환
     */
    fun getTodayTimeTypes(date: String): List<String> {
        val db = readableDatabase
        val list = mutableListOf<String>()

        val cursor = db.rawQuery(
            """
            SELECT DISTINCT ds.time_type
            FROM dose_schedule ds
            JOIN medicine m ON ds.medicine_id = m.medicine_id
            WHERE ? BETWEEN ds.start_date AND ds.end_date
            """.trimIndent(),
            arrayOf(date)
        )

        while (cursor.moveToNext()) {
            list.add(cursor.getString(0))
        }
        cursor.close()

        return list
    }

    /**
     * 특정 날짜 + timeType에 모든 약을 먹었는지 여부
     */
    fun isTimeTypeCompleted(date: String, timeType: String): Boolean {
        val db = readableDatabase

        val cursor = db.rawQuery(
            """
            SELECT 
                COUNT(*) AS total,
                SUM(CASE WHEN COALESCE(il.taken, 0) = 1 THEN 1 ELSE 0 END) AS done
            FROM dose_schedule ds
            JOIN medicine m ON ds.medicine_id = m.medicine_id
            LEFT JOIN intake_log il
                ON ds.schedule_id = il.schedule_id
               AND il.date = ?
            WHERE ds.time_type = ?
              AND ? BETWEEN ds.start_date AND ds.end_date
            """.trimIndent(),
            arrayOf(date, timeType, date)
        )

        var completed = false
        if (cursor.moveToFirst()) {
            val total = cursor.getInt(0)
            val done = cursor.getInt(1)
            completed = (total > 0 && total == done)
        }
        cursor.close()
        return completed
    }

    /**
     * ✅ 과거에 foreign_keys OFF였던 시절에 남은 “고아 intake_log” 정리
     * (달력/통계에 유령 기록 뜨는 거 방지)
     */
    private fun cleanupOrphanLogs() {
        val db = writableDatabase
        db.execSQL(
            """
            DELETE FROM intake_log
            WHERE schedule_id NOT IN (SELECT schedule_id FROM dose_schedule)
            """.trimIndent()
        )
    }

    companion object {
        private const val DB_NAME = "medicine.db"
        private const val DB_VERSION = 2
    }
}
