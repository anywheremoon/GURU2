package com.example.medicineproject.ai

import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONArray
import org.json.JSONObject

/**
 * ✅ OpenAI Responses API (POST https://api.openai.com/v1/responses) 호출용 간단 클라이언트
 *
 * ⚠ 보안 주의
 * - 실제 출시 앱에서는 API Key를 앱에 직접 넣지 마세요.
 *   (서버를 통해 프록시하거나, 안전한 키 관리 방식을 사용하세요.)
 * - 현재 코드는 "프로젝트/데모" 용으로 최소 구현입니다.
 */
object OpenAIClient {

    // TODO: 여기에 본인 OpenAI API Key를 넣거나, BuildConfig/Remote Config로 주입하세요.
    // 예) local.properties -> buildConfigField로 넣는 방식이 더 안전합니다.
    var apiKey: String = "YOUR_OPENAI_API_KEY"

    // 모델은 계정/프로젝트에 따라 사용 가능 목록이 다를 수 있어요.
    // 동작 안 하면 docs에서 모델명 바꿔서 시도하세요.
    private const val MODEL = "gpt-4o-mini"

    private val client = OkHttpClient()

    private val jsonType = "application/json; charset=utf-8".toMediaType()

    /**
     * 선택한 영양제 조합 + 로컬 룰 기반 분석 결과를
     * "사용자가 이해하기 쉬운" 형태로 요약해달라고 요청합니다.
     */
    fun buildRequestBody(selectedNames: List<String>, localAnalysis: String): String {
        val system = """
            너는 '영양제/건강기능식품 복용 기록 앱(약속)'의 도우미야.
            사용자가 선택한 조합과 앱 내부 룰 기반 결과를 바탕으로,
            이해하기 쉬운 설명과 주의 포인트를 "일반 정보" 수준에서 정리해.
            의료적 진단/처방/단정은 절대 하지 말고,
            필요하면 '약사/의사 상담'을 권고해.

            출력 형식:
            - 한 줄 요약(따뜻한 톤)
            - 주의 포인트(있으면 1~3개)
            - 안전하게 챙기는 팁(1~2개)
            - 마지막에: "※ 개인 상태에 따라 다를 수 있어요. 필요 시 전문가와 상담하세요." 고정 문구
        """.trimIndent()

        val user = """
            [사용자가 선택한 영양제]
            ${selectedNames.joinToString(", ")}

            [앱 내부 룰 기반 결과]
            $localAnalysis

            위 정보를 바탕으로, 사용자가 바로 이해할 수 있게 한국어로 정리해줘.
        """.trimIndent()

        val root = JSONObject()
        root.put("model", MODEL)

        // Responses API는 input에 문자열 또는 배열을 넣을 수 있어요.
        // 간단히 instructions + input 텍스트로 구성합니다.
        root.put("instructions", system)
        root.put("input", user)

        // 너무 길게 안 나오도록 적당히 제한
        root.put("max_output_tokens", 220)
        root.put("temperature", 0.3)

        return root.toString()
    }

    /**
     * 동기 호출 (IO 스레드에서 호출하세요)
     */
    fun requestSummary(selectedNames: List<String>, localAnalysis: String): Result<String> {
        if (apiKey.isBlank() || apiKey == "YOUR_OPENAI_API_KEY") {
            return Result.failure(IllegalStateException("OpenAI API Key가 설정되지 않았습니다."))
        }

        val bodyJson = buildRequestBody(selectedNames, localAnalysis)
        val req = Request.Builder()
            .url("https://api.openai.com/v1/responses")
            .addHeader("Authorization", "Bearer $apiKey")
            .addHeader("Content-Type", "application/json")
            .post(bodyJson.toRequestBody(jsonType))
            .build()

        return try {
            client.newCall(req).execute().use { resp ->
                val raw = resp.body?.string().orEmpty()
                if (!resp.isSuccessful) {
                    return Result.failure(RuntimeException("API 오류(${resp.code}): $raw"))
                }
                val text = extractOutputText(raw)
                Result.success(text)
            }
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

/**
 * ✅ 멀티턴 채팅용: 컨텍스트 + 최근 대화(history)를 묶어서 답변을 생성합니다.
 * - 간단 구현을 위해 history를 텍스트로 직렬화해서 input에 넣습니다.
 * - (더 고급) role 구조 배열로 보내는 방식도 가능하지만, 현재 프로젝트에선 이 방식이 가장 안정적입니다.
 */
fun buildChatRequestBody(context: String, history: List<ChatMessage>): String {
    val instructions = context

    val convo = buildString {
        appendLine("[대화 기록]")
        history.forEach { m ->
            val role = when (m.role) {
                ChatRole.USER -> "USER"
                ChatRole.ASSISTANT -> "ASSISTANT"
            }
            appendLine("$role: ${m.text}")
        }
        appendLine()
        appendLine("ASSISTANT:") // 다음 응답 유도
    }.trim()

    val root = JSONObject()
    root.put("model", MODEL)
    root.put("instructions", instructions)
    root.put("input", convo)

    root.put("max_output_tokens", 420)
    root.put("temperature", 0.4)

    return root.toString()
}

/**
 * 동기 호출 (IO 스레드에서 호출하세요)
 */
fun requestChat(context: String, history: List<ChatMessage>): Result<String> {
    if (apiKey.isBlank() || apiKey == "YOUR_OPENAI_API_KEY") {
        return Result.failure(IllegalStateException("OpenAI API Key가 설정되지 않았습니다."))
    }

    val bodyJson = buildChatRequestBody(context, history)
    val req = Request.Builder()
        .url("https://api.openai.com/v1/responses")
        .addHeader("Authorization", "Bearer $apiKey")
        .addHeader("Content-Type", "application/json")
        .post(bodyJson.toRequestBody(jsonType))
        .build()

    return try {
        client.newCall(req).execute().use { resp ->
            val raw = resp.body?.string().orEmpty()
            if (!resp.isSuccessful) {
                return Result.failure(RuntimeException("API 오류(${resp.code}): $raw"))
            }
            val text = extractOutputText(raw)
            Result.success(text)
        }
    } catch (e: Exception) {
        Result.failure(e)
    }
}

    /**
     * Responses API 응답에서 텍스트를 최대한 안전하게 뽑는 함수
     */
    private fun extractOutputText(rawJson: String): String {
        val obj = JSONObject(rawJson)

        // 1) output_text가 있으면 우선 사용
        if (obj.has("output_text")) {
            val t = obj.optString("output_text")
            if (t.isNotBlank()) return t
        }

        // 2) output 배열에서 message -> content -> output_text 찾기
        val output = obj.optJSONArray("output") ?: JSONArray()
        for (i in 0 until output.length()) {
            val item = output.optJSONObject(i) ?: continue
            if (item.optString("type") != "message") continue

            val content = item.optJSONArray("content") ?: continue
            for (j in 0 until content.length()) {
                val c = content.optJSONObject(j) ?: continue
                if (c.optString("type") == "output_text") {
                    val text = c.optString("text")
                    if (text.isNotBlank()) return text
                }
            }
        }

        // 마지막 fallback
        return "(AI 요약을 불러오지 못했어요. 잠시 후 다시 시도해주세요.)"
    }
}
