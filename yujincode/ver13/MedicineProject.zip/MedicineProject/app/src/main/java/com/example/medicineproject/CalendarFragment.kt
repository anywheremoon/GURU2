package com.example.medicineproject

import android.database.sqlite.SQLiteDatabase
import android.graphics.Color
import android.os.Bundle
import android.util.Log
import android.view.View
import android.widget.TextView
import androidx.fragment.app.Fragment
import com.example.medicineproject.calendar.ColorDecorator
import com.example.medicineproject.db.DBHelper
import com.prolificinteractive.materialcalendarview.CalendarDay
import com.prolificinteractive.materialcalendarview.MaterialCalendarView
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Locale

class CalendarFragment : Fragment(R.layout.fragment_calendar) {

    private val dateFormat = SimpleDateFormat("yyyy-MM-dd", Locale.KOREA)

    // 🔹 멤버 변수로 통일
    private lateinit var calendarView: MaterialCalendarView
    private lateinit var tvMonthLabel: TextView
    private lateinit var tvStatus: TextView
    private lateinit var tvDetail: TextView
    private lateinit var db: SQLiteDatabase

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        calendarView = view.findViewById(R.id.calendarView)
        tvStatus = view.findViewById(R.id.tvStatus)
        tvDetail = view.findViewById(R.id.tvDetail)
        tvMonthLabel = view.findViewById(R.id.tvMonthLabel)

        val btnPrevMonth = view.findViewById<View>(R.id.btnPrevMonth)
        val btnNextMonth = view.findViewById<View>(R.id.btnNextMonth)

        db = DBHelper(requireContext()).readableDatabase

        calendarView.topbarVisible = false

        btnPrevMonth.setOnClickListener { calendarView.goToPrevious() }
        btnNextMonth.setOnClickListener { calendarView.goToNext() }

        // 초기 표시
        val today = CalendarDay.today()
        calendarView.setSelectedDate(today)
        calendarView.currentDate = today

        updateMonthLabel(today)
        refreshCalendar(today.year, today.month)
        showDateDetail(today)

        calendarView.setOnMonthChangedListener { _, date ->
            updateMonthLabel(date)
            refreshCalendar(date.year, date.month)
        }

        calendarView.setOnDateChangedListener { _, date, _ ->
            showDateDetail(date)
        }
    }

    override fun onResume() {
        super.onResume()

        val today = CalendarDay.today()

        // 🔥 Today ↔ Calendar 날짜 강제 동기화
        calendarView.setSelectedDate(today)
        calendarView.currentDate = today

        updateMonthLabel(today)
        refreshCalendar(today.year, today.month)
        showDateDetail(today)
    }

    // ======================
    // 📅 월 라벨 업데이트
    // ======================
    private fun updateMonthLabel(date: CalendarDay) {
        val cal = Calendar.getInstance()
        cal.set(date.year, date.month, 1)
        val fmt = SimpleDateFormat("M월", Locale.KOREA)
        tvMonthLabel.text = fmt.format(cal.time)
    }

    // ======================
    // 🎨 캘린더 색상 갱신
    // ======================
    private fun refreshCalendar(year: Int, month0: Int) {
        val completeDates = mutableListOf<CalendarDay>()
        val partialDates = mutableListOf<CalendarDay>()
        val failDates = mutableListOf<CalendarDay>()

        val cal = Calendar.getInstance()
        cal.set(year, month0, 1)
        val daysInMonth = cal.getActualMaximum(Calendar.DAY_OF_MONTH)

        for (day in 1..daysInMonth) {
            cal.set(year, month0, day)
            val dateStr = dateFormat.format(cal.time)

            val cursor = db.rawQuery(
                """
                SELECT
                    COUNT(DISTINCT d.schedule_id) AS total,
                    COUNT(DISTINCT CASE 
                        WHEN i.taken = 0 OR i.taken IS NULL 
                        THEN d.schedule_id 
                    END) AS untaken
                FROM dose_schedule d
                LEFT JOIN intake_log i
                  ON i.schedule_id = d.schedule_id
                 AND i.date = ?
                WHERE ? BETWEEN d.start_date AND d.end_date
                """.trimIndent(),
                arrayOf(dateStr, dateStr)
            )

            if (cursor.moveToFirst()) {
                val total = cursor.getInt(0)
                val untaken = cursor.getInt(1)

                if (total > 0) {
                    Log.d("CalendarCheck", "날짜=$dateStr total=$total untaken=$untaken")
                    val dayObj = CalendarDay.from(year, month0, day)
                    when {
                        untaken == 0 -> completeDates.add(dayObj)
                        untaken == total -> failDates.add(dayObj)
                        else -> partialDates.add(dayObj)
                    }
                }
            }
            cursor.close()
        }

        calendarView.removeDecorators()
        calendarView.addDecorator(ColorDecorator(Color.parseColor("#2E7D32"), completeDates))
        calendarView.addDecorator(ColorDecorator(Color.parseColor("#F59E0B"), partialDates))
        calendarView.addDecorator(ColorDecorator(Color.parseColor("#D32F2F"), failDates))
        calendarView.invalidateDecorators()
    }

    // ======================
    // 📄 날짜 상세 표시
    // ======================
    private fun showDateDetail(date: CalendarDay) {
        val selectedDate = String.format(
            "%04d-%02d-%02d",
            date.year,
            date.month + 1,
            date.day
        )

        val cursor = db.rawQuery(
            """
            SELECT d.time_type, m.name, COALESCE(i.taken, 0)
            FROM dose_schedule d
            JOIN medicine m ON d.medicine_id = m.medicine_id
            LEFT JOIN intake_log i
              ON i.schedule_id = d.schedule_id
             AND i.date = ?
            WHERE ? BETWEEN d.start_date AND d.end_date
            ORDER BY
                CASE d.time_type
                    WHEN '아침' THEN 1
                    WHEN '점심' THEN 2
                    WHEN '저녁' THEN 3
                    WHEN '취침 전' THEN 4
                    ELSE 99
                END
            """.trimIndent(),
            arrayOf(selectedDate, selectedDate)
        )

        val grouped = linkedMapOf<String, MutableList<Pair<String, Boolean>>>()
        while (cursor.moveToNext()) {
            val timeType = cursor.getString(0)
            val name = cursor.getString(1)
            val taken = cursor.getInt(2) == 1
            grouped.getOrPut(timeType) { mutableListOf() }.add(name to taken)
        }
        cursor.close()

        val sb = StringBuilder()
        for (time in listOf("아침", "점심", "저녁", "취침 전")) {
            val list = grouped[time] ?: continue
            sb.append("$time\n")
            for ((name, taken) in list) {
                sb.append("    ${if (taken) "✅" else "❌"} $name\n")
            }
            sb.append("\n")
        }

        tvStatus.text = selectedDate
        tvDetail.text =
            if (sb.isNotEmpty()) sb.toString().trim()
            else "등록된 복용 일정이 없습니다."
    }
}
