package com.example.medicineproject.db

import android.content.Context
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteOpenHelper
import com.example.medicineproject.model.DoseItem
import com.example.medicineproject.model.DoseSet
import android.content.ContentValues


class DBHelper(context: Context) : SQLiteOpenHelper(
    context,
    DB_NAME,
    null,
    DB_VERSION
) {

    override fun onCreate(db: SQLiteDatabase) {
        db.execSQL(
            """
            CREATE TABLE IF NOT EXISTS medicine (
                medicine_id INTEGER PRIMARY KEY AUTOINCREMENT,
                name TEXT NOT NULL,
                category TEXT,
                photo_uri TEXT
            )
            """.trimIndent()
        )

        db.execSQL(
            """
            CREATE TABLE IF NOT EXISTS dose_schedule (
                schedule_id INTEGER PRIMARY KEY AUTOINCREMENT,
                medicine_id INTEGER NOT NULL,
                time_type TEXT NOT NULL,
                amount INTEGER NOT NULL,
                unit TEXT NOT NULL,
                start_date TEXT NOT NULL,
                end_date TEXT NOT NULL,
                FOREIGN KEY(medicine_id) REFERENCES medicine(medicine_id) ON DELETE CASCADE
            )
            """.trimIndent()
        )

        db.execSQL(
            """
            CREATE TABLE IF NOT EXISTS intake_log (
                log_id INTEGER PRIMARY KEY AUTOINCREMENT,
                schedule_id INTEGER NOT NULL,
                date TEXT NOT NULL,
                taken INTEGER NOT NULL DEFAULT 0,
                UNIQUE(schedule_id, date),
                FOREIGN KEY(schedule_id) REFERENCES dose_schedule(schedule_id) ON DELETE CASCADE
            )
            """.trimIndent()
        )

        // 조회 성능용 인덱스(필수는 아니지만 체감 큼)
        db.execSQL("CREATE INDEX IF NOT EXISTS idx_schedule_medicine ON dose_schedule(medicine_id)")
        db.execSQL("CREATE INDEX IF NOT EXISTS idx_schedule_date_range ON dose_schedule(start_date, end_date)")
        db.execSQL("CREATE INDEX IF NOT EXISTS idx_intake_date ON intake_log(date)")
        db.execSQL("CREATE INDEX IF NOT EXISTS idx_intake_schedule_date ON intake_log(schedule_id, date)")
    }

    override fun onUpgrade(db: SQLiteDatabase, oldVersion: Int, newVersion: Int) {
        db.execSQL("DROP TABLE IF EXISTS intake_log")
        db.execSQL("DROP TABLE IF EXISTS dose_schedule")
        db.execSQL("DROP TABLE IF EXISTS medicine")
        onCreate(db)
    }

    /**
     * date: "yyyy-MM-dd"
     * 오늘 날짜에 해당하는 복약 스케줄을 시간대별로 묶어서 반환
     */
    fun getTodayDoseSets(date: String): List<DoseSet> {
        val db = readableDatabase

        val sql = """
        SELECT 
            s.schedule_id,
            s.time_type,
            m.medicine_id,
            m.name,
            s.amount,
            s.unit,
            COALESCE(l.taken, 0) AS taken
        FROM dose_schedule s
        JOIN medicine m ON m.medicine_id = s.medicine_id
        LEFT JOIN intake_log l 
            ON l.schedule_id = s.schedule_id AND l.date = ?
        WHERE ? BETWEEN s.start_date AND s.end_date
        ORDER BY 
            CASE s.time_type
                WHEN '아침' THEN 1
                WHEN '점심' THEN 2
                WHEN '저녁' THEN 3
                WHEN '취침 전' THEN 4
                ELSE 99
            END,
            s.schedule_id ASC
    """.trimIndent()

        val cursor = db.rawQuery(sql, arrayOf(date, date))

        val map = linkedMapOf<String, MutableList<DoseItem>>()

        while (cursor.moveToNext()) {
            val scheduleId = cursor.getInt(0)
            val timeType = cursor.getString(1)
            val medicineId = cursor.getLong(2)   // ✅ 추가
            val name = cursor.getString(3)
            val amount = cursor.getInt(4)
            val unit = cursor.getString(5)
            val taken = cursor.getInt(6) == 1

            val item = DoseItem(
                scheduleId = scheduleId,
                medicineId = medicineId,
                name = name,
                amount = amount,
                unit = unit,
                taken = taken
            )

            val list = map.getOrPut(timeType) { mutableListOf() }
            list.add(item)
        }

        cursor.close()

        return map.entries.map { (timeType, items) ->
            DoseSet(timeType = timeType, items = items)
        }
    }


    /**
     * 체크박스/먹음 처리 시: 해당 날짜(scheduleId, date) 기록을 INSERT 또는 UPDATE
     */
    fun upsertIntake(scheduleId: Int, date: String, taken: Boolean) {
        val db = writableDatabase
        val takenInt = if (taken) 1 else 0

        // UNIQUE(schedule_id, date) 있으니까 INSERT OR REPLACE로 간단 처리
        db.execSQL(
            """
            INSERT OR REPLACE INTO intake_log (schedule_id, date, taken)
            VALUES (?, ?, ?)
            """.trimIndent(),
            arrayOf(scheduleId, date, takenInt)
        )
    }

    fun insertMedicine(name: String, category: String?, photoUri: String? = null): Long {
        val db = writableDatabase
        db.execSQL(
            """
        INSERT INTO medicine (name, category, photo_uri)
        VALUES (?, ?, ?)
        """.trimIndent(),
            arrayOf(name, category, photoUri)
        )

        // 방금 넣은 row id 가져오기
        val cursor = db.rawQuery("SELECT last_insert_rowid()", null)
        cursor.moveToFirst()
        val id = cursor.getLong(0)
        cursor.close()
        return id
    }

    fun insertDoseSchedule(
        medicineId: Long,
        timeType: String,
        amount: Int,
        unit: String,
        startDate: String,
        endDate: String
    ) {
        val db = writableDatabase
        db.execSQL(
            """
        INSERT INTO dose_schedule (medicine_id, time_type, amount, unit, start_date, end_date)
        VALUES (?, ?, ?, ?, ?, ?)
        """.trimIndent(),
            arrayOf(medicineId, timeType, amount, unit, startDate, endDate)
        )
    }

    fun deleteMedicine(medicineId: Long) {
        val db = writableDatabase
        db.delete(
            "medicine",
            "medicine_id = ?",
            arrayOf(medicineId.toString())
        )
    }

    fun updateMedicine(
        medicineId: Long,
        name: String,
        category: String,
        photoUri: String?
    ) {
        val db = writableDatabase
        val values = ContentValues().apply {
            put("name", name)
            put("category", category)
            put("photo_uri", photoUri)
        }

        db.update(
            "medicine",
            values,
            "medicine_id = ?",
            arrayOf(medicineId.toString())
        )
    }



    data class StatsSummary(
        val total: Int,
        val done: Int,
        val missed: Int
    )

    fun getMonthlySummary(month: String): StatsSummary {
        val db = readableDatabase

        val cursor = db.rawQuery(
            """
        SELECT 
            COUNT(*) AS total,
            COALESCE(SUM(CASE WHEN taken = 1 THEN 1 ELSE 0 END), 0) AS done
        FROM intake_log
        WHERE date LIKE ?
        """.trimIndent(),
            arrayOf("$month%")
        )

        var total = 0
        var done = 0

        if (cursor.moveToFirst()) {
            total = cursor.getInt(0)
            done = cursor.getInt(1)
        }
        cursor.close()

        return StatsSummary(
            total = total,
            done = done,
            missed = total - done
        )
    }

    fun getWeeklySummary(lastNDays: Int = 7): StatsSummary {
        val db = readableDatabase

        val cal = java.util.Calendar.getInstance()
        val sdf = java.text.SimpleDateFormat("yyyy-MM-dd", java.util.Locale.KOREA)

        val end = sdf.format(cal.time) // 오늘
        cal.add(java.util.Calendar.DAY_OF_MONTH, -(lastNDays - 1))
        val start = sdf.format(cal.time)

        val cursor = db.rawQuery(
            """
        SELECT 
            COUNT(*) AS total,
            COALESCE(SUM(CASE WHEN taken = 1 THEN 1 ELSE 0 END), 0) AS done
        FROM intake_log
        WHERE date BETWEEN ? AND ?
        """.trimIndent(),
            arrayOf(start, end)
        )

        var total = 0
        var done = 0
        if (cursor.moveToFirst()) {
            total = cursor.getInt(0)
            done = cursor.getInt(1)
        }
        cursor.close()

        return StatsSummary(
            total = total,
            done = done,
            missed = total - done
        )
    }


    fun calcRatePercent(summary: StatsSummary): Int {
        if (summary.total == 0) return 0
        return (summary.done * 100) / summary.total
    }



    companion object {
        private const val DB_NAME = "medicine.db"

        // 기존에 앱 설치해서 DB 만들어져 있을 수 있으니까 버전 올려서 onUpgrade 타게 함
        private const val DB_VERSION = 2
    }
}
