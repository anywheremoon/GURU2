package com.example.medicineproject.adapter

import android.content.Intent
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import com.example.medicineproject.PillDetailActivity
import com.example.medicineproject.R
import android.net.Uri
import android.widget.ImageView

data class MedicineItem(
    val id: Long,
    val name: String,
    val category: String,
    val photoUri: String?
)

class MedicineAdapter(
    private val items: List<MedicineItem>
) : RecyclerView.Adapter<MedicineAdapter.ViewHolder>() {

    class ViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        val tvName: TextView = itemView.findViewById(R.id.tvName)
        val tvCategory: TextView = itemView.findViewById(R.id.tvCategory)
        val imgThumb: ImageView = itemView.findViewById(R.id.imgMedicineThumb)
    }


    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
        val view = LayoutInflater.from(parent.context)
            .inflate(R.layout.item_medicine, parent, false)
        return ViewHolder(view)
    }

    override fun getItemCount(): Int = items.size

    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        val item = items[position]

        holder.tvName.text = item.name
        holder.tvCategory.text = item.category

        if (!item.photoUri.isNullOrEmpty()) {
            holder.imgThumb.setImageURI(Uri.parse(item.photoUri))
        } else {
            holder.imgThumb.setImageResource(android.R.drawable.ic_menu_gallery)
        }
        // 🔥 여기 추가
        holder.itemView.setOnClickListener {
            val context = holder.itemView.context
            val intent = Intent(context, PillDetailActivity::class.java)
            intent.putExtra("medicine_id", item.id)
            context.startActivity(intent)
        }
    }
}
