package com.example.medicineproject

import android.Manifest
import android.app.AlertDialog
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Bundle
import android.provider.MediaStore
import android.view.LayoutInflater
import android.widget.*
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import androidx.core.content.FileProvider
import com.example.medicineproject.db.DBHelper
import com.google.android.material.datepicker.MaterialDatePicker
import com.google.android.material.dialog.MaterialAlertDialogBuilder
import java.io.File
import java.text.SimpleDateFormat
import java.util.*

class AddMedicineActivity : AppCompatActivity() {

    private lateinit var dbHelper: DBHelper
    private var medicineId: Long = -1L

    private val schedules = mutableListOf<ScheduleInput>()

    private lateinit var imgMedicine: ImageView
    private lateinit var btnSelectImage: Button

    private var selectedImageUri: Uri? = null
    private var cameraImageUri: Uri? = null

    // --------------------
    // 앨범 런처
    // --------------------
    private val imagePickerLauncher =
        registerForActivityResult(ActivityResultContracts.GetContent()) { uri ->
            uri?.let {
                selectedImageUri = it
                contentResolver.takePersistableUriPermission(
                    it,
                    Intent.FLAG_GRANT_READ_URI_PERMISSION
                )
                imgMedicine.setImageURI(it)
            }
        }

    // --------------------
    // 카메라 런처
    // --------------------
    private val cameraLauncher =
        registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { result ->
            if (result.resultCode == RESULT_OK) {
                selectedImageUri = cameraImageUri
                imgMedicine.setImageURI(selectedImageUri)
            }
        }

    data class ScheduleInput(
        val timeType: String,
        val amount: Int,
        val unit: String,
        val startDate: String,
        val endDate: String
    )

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_add_medicine)

        dbHelper = DBHelper(this)
        medicineId = intent.getLongExtra("medicine_id", -1L)

        val etName = findViewById<EditText>(R.id.etMedicineName)
        val spinnerCategory = findViewById<Spinner>(R.id.spinnerCategory)
        val btnAddSchedule = findViewById<Button>(R.id.btnAddSchedule)
        val btnSave = findViewById<Button>(R.id.btnSaveMedicine)
        val containerSchedules = findViewById<LinearLayout>(R.id.containerSchedules)

        imgMedicine = findViewById(R.id.imgMedicine)
        btnSelectImage = findViewById(R.id.btnSelectImage)

        // 사진 선택
        btnSelectImage.setOnClickListener {
            showPhotoOptionDialog()
        }

        //뒤로가기
        findViewById<ImageButton>(R.id.btnBack).setOnClickListener {
            finish()
        }

        val categories = listOf("처방약", "일반약", "영양제")
        spinnerCategory.adapter = ArrayAdapter(
            this,
            android.R.layout.simple_spinner_dropdown_item,
            categories
        )

        // 수정 모드
        if (medicineId != -1L) {
            title = "약 정보 수정"
            val db = dbHelper.readableDatabase

            val c1 = db.rawQuery(
                "SELECT name, category, photo_uri FROM medicine WHERE medicine_id = ?",
                arrayOf(medicineId.toString())
            )
            if (c1.moveToFirst()) {
                etName.setText(c1.getString(0))
                spinnerCategory.setSelection(categories.indexOf(c1.getString(1)))

                c1.getString(2)?.let {
                    selectedImageUri = Uri.parse(it)
                    imgMedicine.setImageURI(selectedImageUri)
                }
            }
            c1.close()

            val c2 = db.rawQuery(
                "SELECT time_type, amount, unit, start_date, end_date FROM dose_schedule WHERE medicine_id = ?",
                arrayOf(medicineId.toString())
            )

            schedules.clear()
            while (c2.moveToNext()) {
                schedules.add(
                    ScheduleInput(
                        c2.getString(0),
                        c2.getInt(1),
                        c2.getString(2),
                        c2.getString(3),
                        c2.getString(4)
                    )
                )
            }
            c2.close()

            renderSchedules(containerSchedules)
        } else {
            title = "약 추가"
        }

        btnAddSchedule.setOnClickListener {
            showAddScheduleDialog {
                schedules.add(it)
                renderSchedules(containerSchedules)
            }
        }

        btnSave.setOnClickListener {
            val name = etName.text.toString().trim()
            val category = spinnerCategory.selectedItem.toString()

            if (name.isEmpty()) {
                toast("약 이름을 입력해줘")
                return@setOnClickListener
            }
            if (schedules.isEmpty()) {
                toast("복용 시간을 최소 1개는 추가해줘")
                return@setOnClickListener
            }

            if (medicineId == -1L) {
                val newId = dbHelper.insertMedicine(name, category, selectedImageUri?.toString())
                schedules.forEach {
                    dbHelper.insertDoseSchedule(
                        newId, it.timeType, it.amount, it.unit, it.startDate, it.endDate
                    )
                }
            } else {
                dbHelper.updateMedicine(medicineId, name, category, selectedImageUri?.toString())
                dbHelper.writableDatabase.execSQL(
                    "DELETE FROM dose_schedule WHERE medicine_id = ?",
                    arrayOf(medicineId)
                )
                schedules.forEach {
                    dbHelper.insertDoseSchedule(
                        medicineId, it.timeType, it.amount, it.unit, it.startDate, it.endDate
                    )
                }
            }
            finish()
        }
    }

    // --------------------
    // 사진 선택 다이얼로그
    // --------------------
    private fun showPhotoOptionDialog() {
        val options = arrayOf("앨범에서 선택", "카메라로 촬영")

        MaterialAlertDialogBuilder(this)
            .setTitle("사진 선택")
            .setItems(options) { _, which ->
                when (which) {
                    0 -> imagePickerLauncher.launch("image/*")
                    1 -> openCamera()
                }
            }
            .show()
    }

    private fun openCamera() {
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.CAMERA)
            != PackageManager.PERMISSION_GRANTED
        ) {
            ActivityCompat.requestPermissions(
                this,
                arrayOf(Manifest.permission.CAMERA),
                1001
            )
            return
        }

        val photoFile = createImageFile()
        cameraImageUri = FileProvider.getUriForFile(
            this,
            "${packageName}.fileprovider",
            photoFile
        )

        val intent = Intent(MediaStore.ACTION_IMAGE_CAPTURE)
        intent.putExtra(MediaStore.EXTRA_OUTPUT, cameraImageUri)
        cameraLauncher.launch(intent)
    }

    private fun createImageFile(): File {
        val timeStamp =
            SimpleDateFormat("yyyyMMdd_HHmmss", Locale.getDefault()).format(Date())
        return File.createTempFile("JPEG_${timeStamp}_", ".jpg", cacheDir)
    }

    // --------------------
    // 스케줄 목록 렌더
    // --------------------
    private fun renderSchedules(container: LinearLayout) {
        container.removeAllViews()

        schedules.forEachIndexed { idx, s ->
            val row = LayoutInflater.from(this)
                .inflate(R.layout.item_schedule_preview, container, false)

            val tvInfo = row.findViewById<TextView>(R.id.tvScheduleInfo)
            val btnDelete = row.findViewById<ImageButton>(R.id.btnDeleteSchedule)

            tvInfo.text =
                "${s.timeType} | ${s.amount}${s.unit} | ${s.startDate} ~ ${s.endDate}"

            btnDelete.setOnClickListener {
                schedules.removeAt(idx)
                renderSchedules(container)
            }

            container.addView(row)
        }
    }

    // --------------------
    // 복용 시간 다이얼로그
    // --------------------
    private fun showAddScheduleDialog(onAdded: (ScheduleInput) -> Unit) {
        val view = LayoutInflater.from(this)
            .inflate(R.layout.dialog_add_schedule, null)

        val spinnerTime = view.findViewById<Spinner>(R.id.spinnerTimeType)
        val etAmount = view.findViewById<EditText>(R.id.etDoseAmount)
        val etUnit = view.findViewById<EditText>(R.id.etDoseUnit)
        val etStart = view.findViewById<EditText>(R.id.etStartDate)
        val etEnd = view.findViewById<EditText>(R.id.etEndDate)
        val cbNoEndDate = view.findViewById<CheckBox>(R.id.cbNoEndDate)

        etStart.setOnClickListener { showDatePicker(etStart) }
        etEnd.setOnClickListener { showDatePicker(etEnd) }

        spinnerTime.adapter = ArrayAdapter(
            this,
            android.R.layout.simple_spinner_dropdown_item,
            listOf("아침", "점심", "저녁", "취침 전")
        )

        val dialog = MaterialAlertDialogBuilder(this)
            .setTitle("복용 시간 추가")
            .setView(view)
            .setNegativeButton("취소", null)
            .setPositiveButton("추가", null)
            .create()

        dialog.show()

        dialog.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener {
            val amount = etAmount.text.toString().toIntOrNull() ?: return@setOnClickListener
            val unit = etUnit.text.toString()
            val start = etStart.text.toString()
            val end = if (cbNoEndDate.isChecked) "9999-12-31" else etEnd.text.toString()

            onAdded(
                ScheduleInput(
                    spinnerTime.selectedItem.toString(),
                    amount,
                    unit,
                    start,
                    end
                )
            )
            dialog.dismiss()
        }
    }

    // --------------------
    // ⭐ 날짜 선택 (원래 색 유지 핵심)
    // --------------------
    private fun showDatePicker(target: EditText) {
        val picker = MaterialDatePicker.Builder.datePicker()
            .setTitleText("선택한 날짜")
            // ✅ 이 한 줄이 빠져서 색이 바뀌었던 것
            .setTheme(R.style.ThemeOverlay_MedicineProject_Calendar)
            .build()

        picker.addOnPositiveButtonClickListener { selection ->
            val cal = Calendar.getInstance(TimeZone.getTimeZone("UTC"))
            cal.timeInMillis = selection

            target.setText(
                String.format(
                    "%04d-%02d-%02d",
                    cal.get(Calendar.YEAR),
                    cal.get(Calendar.MONTH) + 1,
                    cal.get(Calendar.DAY_OF_MONTH)
                )
            )
        }

        picker.show(supportFragmentManager, "DATE_PICKER")
    }

    private fun toast(msg: String) {
        Toast.makeText(this, msg, Toast.LENGTH_SHORT).show()
    }

    override fun onRequestPermissionsResult(
        requestCode: Int,
        permissions: Array<out String>,
        grantResults: IntArray
    ) {
        if (requestCode == 1001 &&
            grantResults.isNotEmpty() &&
            grantResults[0] == PackageManager.PERMISSION_GRANTED
        ) {
            openCamera()
        }
    }
}
