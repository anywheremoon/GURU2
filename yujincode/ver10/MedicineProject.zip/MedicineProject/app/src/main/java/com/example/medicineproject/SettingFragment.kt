package com.example.medicineproject

import android.app.AlertDialog
import android.os.Bundle
import android.view.View
import android.widget.Button
import android.widget.Switch
import android.widget.Toast
import androidx.fragment.app.Fragment
import com.example.medicineproject.db.DBHelper
import com.example.medicineproject.alarm.AlarmScheduler
import com.example.medicineproject.alarm.AlarmSettingFragment
import android.content.Context
import com.google.android.material.dialog.MaterialAlertDialogBuilder

// 🔥 여기 추가
private const val PREF_ALARM_ENABLED = "alarm_enabled"

class SettingsFragment : Fragment(R.layout.fragment_setting) {

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        val switchAlarm = view.findViewById<Switch>(R.id.switchAlarm)
        val btnEnableAlarm = view.findViewById<Button>(R.id.btnEnableAlarm)
        val btnReset = view.findViewById<Button>(R.id.btnReset)
        val dbHelper = DBHelper(requireContext())

        val prefs = requireContext()
            .getSharedPreferences("alarm_prefs", Context.MODE_PRIVATE)

        // ✅ 스위치 초기 상태
        switchAlarm.isChecked = prefs.getBoolean(PREF_ALARM_ENABLED, true)

        // ✅ 스위치 실제 동작
        switchAlarm.setOnCheckedChangeListener { _, isChecked ->
            prefs.edit()
                .putBoolean(PREF_ALARM_ENABLED, isChecked)
                .apply()

            // 🔥 여기 한 줄이 전부
            AlarmScheduler.rescheduleToday(requireContext())

            Toast.makeText(
                requireContext(),
                if (isChecked) "복용 알림이 켜졌습니다"
                else "복용 알림이 꺼졌습니다",
                Toast.LENGTH_SHORT
            ).show()
        }


        // ▶ 알람 시간 설정 화면 이동 (기존 로직 유지)
        btnEnableAlarm.setOnClickListener {
            parentFragmentManager.beginTransaction()
                .replace(R.id.container, AlarmSettingFragment())
                .addToBackStack(null)
                .commit()
        }

        // ▶ 데이터 초기화 (기존 로직 유지)
        btnReset.setOnClickListener {
            MaterialAlertDialogBuilder(requireContext())
                .setTitle("데이터 초기화")
                .setMessage("모든 약 정보와 복용 기록이 삭제됩니다.\n정말 초기화할까요?")
                .setPositiveButton("초기화") { _, _ ->
                    dbHelper.clearAllData()
                    Toast.makeText(
                        requireContext(),
                        "모든 데이터가 초기화되었습니다",
                        Toast.LENGTH_SHORT
                    ).show()
                }
                .setNegativeButton("취소", null)
                .show()
        }
    }
}
