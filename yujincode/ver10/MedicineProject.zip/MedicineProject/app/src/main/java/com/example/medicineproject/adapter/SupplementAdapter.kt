package com.example.medicineproject.adapter

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.CheckBox
import androidx.recyclerview.widget.RecyclerView
import com.example.medicineproject.R

data class Supplement(
    val id: String,
    val name: String,
    var checked: Boolean = false
)

class SupplementAdapter(
    private val allItems: List<Supplement>
) : RecyclerView.Adapter<SupplementAdapter.ViewHolder>() {

    private val filteredItems = allItems.toMutableList()

    inner class ViewHolder(view: View) : RecyclerView.ViewHolder(view) {
        val checkBox: CheckBox = view.findViewById(R.id.cbSupplement)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
        val view = LayoutInflater.from(parent.context)
            .inflate(R.layout.item_supplement_checkbox, parent, false)
        return ViewHolder(view)
    }

    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        val item = filteredItems[position]
        holder.checkBox.text = item.name
        holder.checkBox.isChecked = item.checked

        holder.checkBox.setOnCheckedChangeListener { _, isChecked ->
            item.checked = isChecked
        }
    }

    override fun getItemCount(): Int = filteredItems.size

    fun getSelectedIds(): List<String> =
        allItems.filter { it.checked }.map { it.id }

    // 🔍 검색 필터
    fun filter(query: String) {
        filteredItems.clear()

        if (query.isBlank()) {
            filteredItems.addAll(allItems)
        } else {
            filteredItems.addAll(
                allItems.filter {
                    it.name.contains(query, ignoreCase = true)
                }
            )
        }
        notifyDataSetChanged()
    }
}
