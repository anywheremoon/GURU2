package com.example.medicineproject

import android.os.Bundle
import android.view.View
import android.widget.Button
import android.widget.TextView
import androidx.fragment.app.Fragment
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.example.medicineproject.adapter.Supplement
import com.example.medicineproject.adapter.SupplementAdapter
import org.json.JSONArray
import android.text.Editable
import android.text.TextWatcher
import android.widget.EditText
import android.widget.ImageButton


class SupplementCombinationFragment
    : Fragment(R.layout.fragment_supplement_combination) {

    // ===============================
    // 조합 규칙 관련 타입
    // ===============================
    enum class Level { GOOD, CAUTION, BAD }

    data class InteractionRule(
        val a: String,
        val b: String,
        val level: Level,
        val reason: String
    )

    private lateinit var adapter: SupplementAdapter
    private lateinit var rules: List<InteractionRule>

    // ===============================
    // Fragment 생명주기
    // ===============================
    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        val btnBack = view.findViewById<ImageButton>(R.id.btnBack)

        btnBack.setOnClickListener {
            requireActivity()
                .onBackPressedDispatcher
                .onBackPressed()
        }

        val rvSupplements = view.findViewById<RecyclerView>(R.id.rvSupplements)
        val btnAnalyze = view.findViewById<Button>(R.id.btnAnalyze)
        val tvResult = view.findViewById<TextView>(R.id.tvResult)

        // 🔹 JSON 데이터 로드
        val supplements = loadSupplementsFromJson()
        rules = loadRulesFromJson()

        adapter = SupplementAdapter(supplements)

        rvSupplements.layoutManager = LinearLayoutManager(requireContext())
        rvSupplements.adapter = adapter

        btnAnalyze.setOnClickListener {
            val selected = adapter.getSelectedIds()
            tvResult.text = analyzeCombination(selected)
        }

        val etSearch = view.findViewById<EditText>(R.id.etSearch)

        etSearch.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}

            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {
                adapter.filter(s.toString())
            }

            override fun afterTextChanged(s: Editable?) {}
        })

    }

    // ===============================
    // 영양제 목록 로드 (supplements.json)
    // ===============================
    private fun loadSupplementsFromJson(): List<Supplement> {
        val json = requireContext().assets
            .open("supplements.json")
            .bufferedReader()
            .use { it.readText() }

        val array = JSONArray(json)
        val list = mutableListOf<Supplement>()

        for (i in 0 until array.length()) {
            val obj = array.getJSONObject(i)
            list.add(
                Supplement(
                    id = obj.getString("id"),
                    name = obj.getString("name")
                )
            )
        }
        return list
    }

    // ===============================
    // 조합 규칙 로드 (interaction_rules.json)
    // ===============================
    private fun loadRulesFromJson(): List<InteractionRule> {
        val json = requireContext().assets
            .open("interaction_rules.json")
            .bufferedReader()
            .use { it.readText() }

        val array = JSONArray(json)
        val list = mutableListOf<InteractionRule>()

        for (i in 0 until array.length()) {
            val obj = array.getJSONObject(i)

            list.add(
                InteractionRule(
                    a = obj.getString("a"),
                    b = obj.getString("b"),
                    level = Level.valueOf(obj.getString("level")),
                    reason = obj.getString("reason")
                )
            )
        }
        return list
    }

    // ===============================
    // 조합 분석 로직
    // ===============================
    private fun analyzeCombination(selected: List<String>): String {
        if (selected.size < 2) {
            return "⚠ 2개 이상의 영양제를 선택해주세요."
        }

        val results = mutableListOf<String>()

        for (i in selected.indices) {
            for (j in i + 1 until selected.size) {
                val a = selected[i]
                val b = selected[j]

                rules.find {
                    (it.a == a && it.b == b) || (it.a == b && it.b == a)
                }?.let { rule ->
                    val icon = when (rule.level) {
                        Level.GOOD -> "🟢"
                        Level.CAUTION -> "🟡"
                        Level.BAD -> "🔴"
                    }

                    results.add(
                        "$icon ${toKorean(a)} + ${toKorean(b)}\n- ${rule.reason}"
                    )
                }
            }
        }

        return if (results.isEmpty()) {
            "✅ 선택한 조합에서 특별한 주의사항은 발견되지 않았어요."
        } else {
            "📌 조합 분석 결과\n\n" +
                    results.joinToString("\n\n")
        }
    }

    // ===============================
    // 내부 ID → 한글 이름
    // ===============================
    private fun toKorean(id: String): String = when (id) {
        "vitamin_c" -> "비타민 C"
        "vitamin_d" -> "비타민 D"
        "zinc" -> "아연"
        "magnesium" -> "마그네슘"
        "omega3" -> "오메가3"
        "iron" -> "철분"
        else -> id
    }
}
