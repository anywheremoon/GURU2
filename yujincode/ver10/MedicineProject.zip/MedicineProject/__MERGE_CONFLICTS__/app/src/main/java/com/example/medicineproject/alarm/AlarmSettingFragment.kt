package com.example.medicineproject.alarm

import android.app.TimePickerDialog
import android.content.Context
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.LinearLayout
import android.widget.TextView
import androidx.fragment.app.Fragment
import com.example.medicineproject.R
import java.util.Calendar
import java.util.Locale

class AlarmSettingFragment : Fragment() {

    private val prefs by lazy {
        requireContext().getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
    }

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        return inflater.inflate(R.layout.fragment_alarm_setting, container, false)
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        val btnBack = view.findViewById<TextView>(R.id.btnBack)

        val rowMorning = view.findViewById<LinearLayout>(R.id.rowMorning)
        val rowLunch = view.findViewById<LinearLayout>(R.id.rowLunch)
        val rowDinner = view.findViewById<LinearLayout>(R.id.rowDinner)
        val rowBedtime = view.findViewById<LinearLayout>(R.id.rowBedtime)

        val txtMorning = view.findViewById<TextView>(R.id.txtMorningTime)
        val txtLunch = view.findViewById<TextView>(R.id.txtLunchTime)
        val txtDinner = view.findViewById<TextView>(R.id.txtDinnerTime)
        val txtBedtime = view.findViewById<TextView>(R.id.txtBedtimeTime)

        // 1) 저장값(없으면 기본값) 로드해서 표시
        txtMorning.text = formatTime(getHour(KEY_MORNING_H, 8), getMin(KEY_MORNING_M, 0))
        txtLunch.text = formatTime(getHour(KEY_LUNCH_H, 12), getMin(KEY_LUNCH_M, 30))
        txtDinner.text = formatTime(getHour(KEY_DINNER_H, 18), getMin(KEY_DINNER_M, 30))
        txtBedtime.text = formatTime(getHour(KEY_BEDTIME_H, 22), getMin(KEY_BEDTIME_M, 0))

        // 2) 뒤로가기
        btnBack.setOnClickListener {
            parentFragmentManager.popBackStack()
        }

        // 3) 각 row 클릭 -> TimePicker -> 저장 + UI 갱신
        rowMorning.setOnClickListener {
            openPicker(
                title = "아침 알림 시간",
                initH = getHour(KEY_MORNING_H, 8),
                initM = getMin(KEY_MORNING_M, 0)
            ) { h, m ->
                saveTime(KEY_MORNING_H, KEY_MORNING_M, h, m)
                txtMorning.text = formatTime(h, m)

                // 🔥 추가
                AlarmScheduler.rescheduleToday(requireContext())
            }
        }

        rowLunch.setOnClickListener {
            openPicker(
                title = "점심 알림 시간",
                initH = getHour(KEY_LUNCH_H, 12),
                initM = getMin(KEY_LUNCH_M, 30)
            ) { h, m ->
                saveTime(KEY_LUNCH_H, KEY_LUNCH_M, h, m)
                txtLunch.text = formatTime(h, m)
            }
        }

        rowDinner.setOnClickListener {
            openPicker(
                title = "저녁 알림 시간",
                initH = getHour(KEY_DINNER_H, 18),
                initM = getMin(KEY_DINNER_M, 30)
            ) { h, m ->
                saveTime(KEY_DINNER_H, KEY_DINNER_M, h, m)
                txtDinner.text = formatTime(h, m)
            }
        }

        rowBedtime.setOnClickListener {
            openPicker(
                title = "취침 전 알림 시간",
                initH = getHour(KEY_BEDTIME_H, 22),
                initM = getMin(KEY_BEDTIME_M, 0)
            ) { h, m ->
                saveTime(KEY_BEDTIME_H, KEY_BEDTIME_M, h, m)
                txtBedtime.text = formatTime(h, m)
            }
        }
    }

    private fun openPicker(
        title: String,
        initH: Int,
        initM: Int,
        onPicked: (h: Int, m: Int) -> Unit
    ) {
        val dialog = TimePickerDialog(
            requireContext(),
            { _, h, m -> onPicked(h, m) },
            initH,
            initM,
            true
        )
        dialog.setTitle(title)
        dialog.show()
    }

    private fun saveTime(keyH: String, keyM: String, h: Int, m: Int) {
        prefs.edit()
            .putInt(keyH, h)
            .putInt(keyM, m)
            .apply()
    }

    private fun getHour(key: String, defaultValue: Int): Int = prefs.getInt(key, defaultValue)
    private fun getMin(key: String, defaultValue: Int): Int = prefs.getInt(key, defaultValue)

    private fun formatTime(h: Int, m: Int): String =
        String.format(Locale.KOREA, "%02d:%02d", h, m)

    companion object {
        private const val PREFS_NAME = "alarm_prefs"

        private const val KEY_MORNING_H = "morning_hour"
        private const val KEY_MORNING_M = "morning_min"

        private const val KEY_LUNCH_H = "lunch_hour"
        private const val KEY_LUNCH_M = "lunch_min"

        private const val KEY_DINNER_H = "dinner_hour"
        private const val KEY_DINNER_M = "dinner_min"

        private const val KEY_BEDTIME_H = "bedtime_hour"
        private const val KEY_BEDTIME_M = "bedtime_min"
    }
}