package com.example.medicineproject.alarm

import android.content.Context
import android.os.Bundle
import android.util.TypedValue
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageButton
import android.widget.LinearLayout
import android.widget.TextView
import androidx.fragment.app.Fragment
import com.example.medicineproject.R
import com.google.android.material.timepicker.MaterialTimePicker
import com.google.android.material.timepicker.TimeFormat
import java.util.Locale
import kotlin.math.abs

class AlarmSettingFragment : Fragment() {

    private val prefs by lazy {
        requireContext().getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
    }

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        return inflater.inflate(R.layout.fragment_alarm_setting, container, false)
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        val btnBack = view.findViewById<TextView>(R.id.btnBack)

        val rowMorning = view.findViewById<LinearLayout>(R.id.rowMorning)
        val rowLunch = view.findViewById<LinearLayout>(R.id.rowLunch)
        val rowDinner = view.findViewById<LinearLayout>(R.id.rowDinner)
        val rowBedtime = view.findViewById<LinearLayout>(R.id.rowBedtime)

        val txtMorning = view.findViewById<TextView>(R.id.txtMorningTime)
        val txtLunch = view.findViewById<TextView>(R.id.txtLunchTime)
        val txtDinner = view.findViewById<TextView>(R.id.txtDinnerTime)
        val txtBedtime = view.findViewById<TextView>(R.id.txtBedtimeTime)

        txtMorning.text = formatTime(getHour(KEY_MORNING_H, 8), getMin(KEY_MORNING_M, 0))
        txtLunch.text = formatTime(getHour(KEY_LUNCH_H, 12), getMin(KEY_LUNCH_M, 30))
        txtDinner.text = formatTime(getHour(KEY_DINNER_H, 18), getMin(KEY_DINNER_M, 30))
        txtBedtime.text = formatTime(getHour(KEY_BEDTIME_H, 22), getMin(KEY_BEDTIME_M, 0))

        btnBack.setOnClickListener { parentFragmentManager.popBackStack() }

        rowMorning.setOnClickListener {
            openPicker(
                title = "아침 알림 시간",
                initH = getHour(KEY_MORNING_H, 8),
                initM = getMin(KEY_MORNING_M, 0)
            ) { h, m ->
                saveTime(KEY_MORNING_H, KEY_MORNING_M, h, m)
                txtMorning.text = formatTime(h, m)
                AlarmScheduler.rescheduleToday(requireContext())
            }
        }

        rowLunch.setOnClickListener {
            openPicker(
                title = "점심 알림 시간",
                initH = getHour(KEY_LUNCH_H, 12),
                initM = getMin(KEY_LUNCH_M, 30)
            ) { h, m ->
                saveTime(KEY_LUNCH_H, KEY_LUNCH_M, h, m)
                txtLunch.text = formatTime(h, m)
                AlarmScheduler.rescheduleToday(requireContext())
            }
        }

        rowDinner.setOnClickListener {
            openPicker(
                title = "저녁 알림 시간",
                initH = getHour(KEY_DINNER_H, 18),
                initM = getMin(KEY_DINNER_M, 30)
            ) { h, m ->
                saveTime(KEY_DINNER_H, KEY_DINNER_M, h, m)
                txtDinner.text = formatTime(h, m)
                AlarmScheduler.rescheduleToday(requireContext())
            }
        }

        rowBedtime.setOnClickListener {
            openPicker(
                title = "취침 전 알림 시간",
                initH = getHour(KEY_BEDTIME_H, 22),
                initM = getMin(KEY_BEDTIME_M, 0)
            ) { h, m ->
                saveTime(KEY_BEDTIME_H, KEY_BEDTIME_M, h, m)
                txtBedtime.text = formatTime(h, m)
                AlarmScheduler.rescheduleToday(requireContext())
            }
        }
    }

    private fun openPicker(
        title: String,
        initH: Int,
        initM: Int,
        onPicked: (Int, Int) -> Unit
    ) {
        val picker = MaterialTimePicker.Builder()
            .setTitleText(title)
            .setTimeFormat(TimeFormat.CLOCK_24H)
            .setHour(initH)
            .setMinute(initM)
            .setTheme(R.style.ThemeOverlay_MedicineProject_TimePickerWhite)
            .build()

        picker.addOnPositiveButtonClickListener {
            onPicked(picker.hour, picker.minute)
        }

        picker.show(parentFragmentManager, "MATERIAL_TIME_PICKER")

        // ✅ 핵심: view?.post 말고 "다이얼로그 decorView.post"로 타이밍 잡기
        parentFragmentManager.executePendingTransactions()
        val dialog = picker.dialog ?: return
        val root = dialog.window?.decorView as? ViewGroup ?: return

        root.post {
            hideMaterialTimePickerToggle(root)
        }
    }

    /**
     * MaterialTimePicker 좌하단 시계/키보드 토글 버튼 숨기기
     * - 1) 내부 리소스 id 이름으로 찾기
     * - 2) contentDescription 키워드로 찾기
     * - 3) 마지막: 좌하단에 가장 가까운 작은 ImageButton 숨기기
     */
    private fun hideMaterialTimePickerToggle(root: ViewGroup) {
        // 1) id 이름으로 찾기 (패키지 2개 모두 시도)
        val idNames = listOf(
            "material_timepicker_mode_button",
            "material_time_picker_mode_button",
            "material_clock_display_toggle",
            "material_timepicker_toggle",
            "material_timepicker_toggle_button"
        )

        for (name in idNames) {
            // 앱 패키지
            val idApp = resources.getIdentifier(name, "id", requireContext().packageName)
            if (idApp != 0) {
                root.findViewById<View>(idApp)?.let {
                    it.visibility = View.GONE
                    return
                }
            }
            // Material 패키지
            val idMat = resources.getIdentifier(name, "id", "com.google.android.material")
            if (idMat != 0) {
                root.findViewById<View>(idMat)?.let {
                    it.visibility = View.GONE
                    return
                }
            }
        }

        // 2) contentDescription 키워드로 찾기
        val stack = ArrayDeque<View>()
        stack.add(root)
        while (stack.isNotEmpty()) {
            val v = stack.removeFirst()

            val desc = v.contentDescription?.toString()?.lowercase() ?: ""
            val hit = desc.contains("keyboard") ||
                    desc.contains("clock") ||
                    desc.contains("toggle") ||
                    desc.contains("switch") ||
                    desc.contains("mode") ||
                    desc.contains("input") ||
                    desc.contains("키보드") ||
                    desc.contains("시계") ||
                    desc.contains("전환")

            if (hit && (v is ImageButton)) {
                v.visibility = View.GONE
                return
            }

            if (v is ViewGroup) {
                for (i in 0 until v.childCount) stack.add(v.getChildAt(i))
            }
        }

        // 3) 마지막 수단: 좌하단 가장 가까운 작은 ImageButton 숨기기
        hideBottomLeftSmallImageButton(root)
    }

    private fun hideBottomLeftSmallImageButton(root: ViewGroup) {
        val candidates = ArrayList<ImageButton>()

        val stack = ArrayDeque<View>()
        stack.add(root)
        while (stack.isNotEmpty()) {
            val v = stack.removeFirst()
            if (v is ImageButton && v.visibility == View.VISIBLE) {
                candidates.add(v)
            } else if (v is ViewGroup) {
                for (i in 0 until v.childCount) stack.add(v.getChildAt(i))
            }
        }
        if (candidates.isEmpty()) return

        val rootLoc = IntArray(2)
        root.getLocationOnScreen(rootLoc)
        val rootLeft = rootLoc[0]
        val rootTop = rootLoc[1]
        val rootRight = rootLeft + root.width
        val rootBottom = rootTop + root.height

        val maxIconSizePx = dpToPx(72f)

        var best: ImageButton? = null
        var bestScore = Float.MAX_VALUE

        val btnLoc = IntArray(2)

        for (btn in candidates) {
            if (btn.width <= 0 || btn.height <= 0) continue
            if (btn.width > maxIconSizePx || btn.height > maxIconSizePx) continue

            btn.getLocationOnScreen(btnLoc)
            val x = btnLoc[0]
            val y = btnLoc[1]

            // root 내부에 있는 버튼만
            if (x < rootLeft || x > rootRight || y < rootTop || y > rootBottom) continue

            // 좌하단(rootLeft, rootBottom)에 가까울수록 best
            val dx = abs(x - rootLeft).toFloat()
            val dy = abs(y - rootBottom).toFloat()
            val score = dx + dy

            if (score < bestScore) {
                bestScore = score
                best = btn
            }
        }

        best?.visibility = View.GONE
    }

    private fun dpToPx(dp: Float): Int {
        return TypedValue.applyDimension(
            TypedValue.COMPLEX_UNIT_DIP,
            dp,
            resources.displayMetrics
        ).toInt()
    }

    private fun saveTime(keyH: String, keyM: String, h: Int, m: Int) {
        prefs.edit().putInt(keyH, h).putInt(keyM, m).apply()
    }

    private fun getHour(key: String, defaultValue: Int): Int = prefs.getInt(key, defaultValue)
    private fun getMin(key: String, defaultValue: Int): Int = prefs.getInt(key, defaultValue)

    private fun formatTime(h: Int, m: Int): String =
        String.format(Locale.KOREA, "%02d:%02d", h, m)

    companion object {
        private const val PREFS_NAME = "alarm_prefs"

        private const val KEY_MORNING_H = "morning_hour"
        private const val KEY_MORNING_M = "morning_min"

        private const val KEY_LUNCH_H = "lunch_hour"
        private const val KEY_LUNCH_M = "lunch_min"

        private const val KEY_DINNER_H = "dinner_hour"
        private const val KEY_DINNER_M = "dinner_min"

        private const val KEY_BEDTIME_H = "bedtime_hour"
        private const val KEY_BEDTIME_M = "bedtime_min"
    }
}
