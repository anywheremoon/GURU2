package com.example.medicineproject

import android.app.DatePickerDialog
import android.graphics.Paint
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.widget.CheckBox
import android.widget.LinearLayout
import android.widget.TextView
import androidx.cardview.widget.CardView
import androidx.fragment.app.Fragment
import com.example.medicineproject.alarm.AlarmScheduler
import com.example.medicineproject.db.DBHelper
import com.example.medicineproject.model.DoseSet
import java.text.SimpleDateFormat
import java.util.*
import android.content.Intent

class TodayFragment : Fragment(R.layout.fragment_today) {

    private lateinit var dbHelper: DBHelper
    private lateinit var tvHeaderDate: TextView
    private lateinit var tvHeaderTitle: TextView
    private lateinit var emptyState: View
    private lateinit var contentState: View

    // 4개 카드뷰
    private lateinit var cardMorning: CardView
    private lateinit var cardLunch: CardView
    private lateinit var cardDinner: CardView
    private lateinit var cardBedtime: CardView

    // 약 목록 컨테이너
    private lateinit var containerMorning: LinearLayout
    private lateinit var containerLunch: LinearLayout
    private lateinit var containerDinner: LinearLayout
    private lateinit var containerBedtime: LinearLayout

    private val dbDateFormat = SimpleDateFormat("yyyy-MM-dd", Locale.KOREA)
    private val uiDateFormat = SimpleDateFormat("yyyy년 M월 d일 (E)", Locale.KOREA)

    private val selectedCal: Calendar = Calendar.getInstance()

    private lateinit var today: String
    private var doseSets: List<DoseSet> = emptyList()

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        dbHelper = DBHelper(requireContext())

        tvHeaderDate = view.findViewById(R.id.tvHeaderDate)
        tvHeaderTitle = view.findViewById(R.id.tvHeaderTitle)
        emptyState = view.findViewById(R.id.emptyState)
        contentState = view.findViewById(R.id.contentState)

        cardMorning = view.findViewById(R.id.cardMorning)
        cardLunch = view.findViewById(R.id.cardLunch)
        cardDinner = view.findViewById(R.id.cardDinner)
        cardBedtime = view.findViewById(R.id.cardBedtime)

        containerMorning = view.findViewById(R.id.containerMorning)
        containerLunch = view.findViewById(R.id.containerLunch)
        containerDinner = view.findViewById(R.id.containerDinner)
        containerBedtime = view.findViewById(R.id.containerBedtime)

        // 안티앨리어싱 적용
        applyAntiAliasing()

        syncDateAndReload()

        tvHeaderDate.setOnClickListener {
            openDatePicker()
        }
    }

    private fun applyAntiAliasing() {
        tvHeaderTitle.paintFlags = tvHeaderTitle.paintFlags or Paint.ANTI_ALIAS_FLAG
        tvHeaderDate.paintFlags = tvHeaderDate.paintFlags or Paint.ANTI_ALIAS_FLAG
    }

    override fun onResume() {
        super.onResume()
        syncDateAndReload()
        AlarmScheduler.rescheduleToday(requireContext())
    }

    private fun openDatePicker() {
        val y = selectedCal.get(Calendar.YEAR)
        val m = selectedCal.get(Calendar.MONTH)
        val d = selectedCal.get(Calendar.DAY_OF_MONTH)

        DatePickerDialog(
            requireContext(),
            { _, year, month, dayOfMonth ->
                selectedCal.set(Calendar.YEAR, year)
                selectedCal.set(Calendar.MONTH, month)
                selectedCal.set(Calendar.DAY_OF_MONTH, dayOfMonth)
                syncDateAndReload()
            },
            y, m, d
        ).show()
    }

    private fun syncDateAndReload() {
        val dateObj = selectedCal.time
        today = dbDateFormat.format(dateObj)
        tvHeaderDate.text = uiDateFormat.format(dateObj)
        loadByDate(today)
    }

    private fun loadByDate(date: String) {
        doseSets = dbHelper.getTodayDoseSets(date)

        val isEmpty = doseSets.isEmpty() || doseSets.all { it.items.isEmpty() }
        emptyState.visibility = if (isEmpty) View.VISIBLE else View.GONE
        contentState.visibility = if (isEmpty) View.GONE else View.VISIBLE

        updateCards()
    }

    private fun updateCards() {
        // 아침 복용 세트
        val morningSets = doseSets.filter { it.timeType.contains("아침") && it.items.isNotEmpty() }
        if (morningSets.isNotEmpty()) {
            cardMorning.visibility = View.VISIBLE
            populateMedicineContainer(containerMorning, morningSets)
        } else {
            cardMorning.visibility = View.GONE
        }

        // 점심 복용 세트
        val lunchSets = doseSets.filter { it.timeType.contains("점심") && it.items.isNotEmpty() }
        if (lunchSets.isNotEmpty()) {
            cardLunch.visibility = View.VISIBLE
            populateMedicineContainer(containerLunch, lunchSets)
        } else {
            cardLunch.visibility = View.GONE
        }

        // 저녁 복용 세트
        val dinnerSets = doseSets.filter { it.timeType.contains("저녁") && it.items.isNotEmpty() }
        if (dinnerSets.isNotEmpty()) {
            cardDinner.visibility = View.VISIBLE
            populateMedicineContainer(containerDinner, dinnerSets)
        } else {
            cardDinner.visibility = View.GONE
        }

        // 취침 전 복용 세트
        val bedtimeSets = doseSets.filter { it.timeType.contains("취침") && it.items.isNotEmpty() }
        if (bedtimeSets.isNotEmpty()) {
            cardBedtime.visibility = View.VISIBLE
            populateMedicineContainer(containerBedtime, bedtimeSets)
        } else {
            cardBedtime.visibility = View.GONE
        }
    }

    private fun populateMedicineContainer(container: LinearLayout, doseSets: List<DoseSet>) {
        container.removeAllViews()

        for (doseSet in doseSets) {
            for (item in doseSet.items) {
                val row = LayoutInflater.from(requireContext())
                    .inflate(R.layout.item_dose_item, container, false)

                val tvMedicine = row.findViewById<TextView>(R.id.tvMedicineInfo)
                val checkBox = row.findViewById<CheckBox>(R.id.checkTaken)

                tvMedicine.text = "- ${item.name} ${item.amount}${item.unit}"

                // 🔥 취소선 제거, 색상+투명도만 사용
                fun updateStrikeThrough(isChecked: Boolean) {
                    if (isChecked) {
                        tvMedicine.alpha = 0.4f  // 흐리게
                        tvMedicine.setTextColor(0xFF9E9E9E.toInt())  // 회색
                    } else {
                        tvMedicine.alpha = 1.0f  // 선명하게
                        tvMedicine.setTextColor(0xFF2F3A22.toInt())  // 원래 색상
                    }
                }

                checkBox.setOnCheckedChangeListener(null)
                checkBox.isChecked = item.taken
                updateStrikeThrough(item.taken)

                checkBox.setOnCheckedChangeListener { _, isChecked ->
                    item.taken = isChecked
                    updateStrikeThrough(isChecked)
                    dbHelper.upsertIntake(item.scheduleId, today, isChecked)

                    if (isChecked) {
                        if (dbHelper.isTimeTypeCompleted(today, doseSet.timeType)) {
                            val requestCode = when (doseSet.timeType) {
                                "아침" -> 100
                                "점심" -> 101
                                "저녁" -> 102
                                "취침 전" -> 103
                                else -> null
                            }
                            requestCode?.let {
                                AlarmScheduler.cancel(requireContext(), it)
                            }
                        }
                    }

                    AlarmScheduler.rescheduleToday(requireContext())
                }

                row.setOnClickListener {
                    val intent = Intent(requireContext(), PillDetailActivity::class.java)
                    intent.putExtra("medicine_id", item.medicineId)
                    startActivity(intent)
                }

                container.addView(row)
            }
        }
    }
}