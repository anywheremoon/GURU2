package com.example.medicineproject

import android.database.sqlite.SQLiteDatabase
import android.graphics.Color
import android.os.Bundle
import android.util.Log
import android.view.View
import android.widget.TextView
import androidx.fragment.app.Fragment
import com.example.medicineproject.calendar.ColorDecorator
import com.example.medicineproject.db.DBHelper
import com.prolificinteractive.materialcalendarview.CalendarDay
import com.prolificinteractive.materialcalendarview.MaterialCalendarView
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Locale

class CalendarFragment : Fragment(R.layout.fragment_calendar) {

    private val dateFormat = SimpleDateFormat("yyyy-MM-dd", Locale.KOREA)

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        val calendarView = view.findViewById<MaterialCalendarView>(R.id.calendarView)
        val tvStatus = view.findViewById<TextView>(R.id.tvStatus)
        val tvDetail = view.findViewById<TextView>(R.id.tvDetail)

        val btnPrevMonth = view.findViewById<View>(R.id.btnPrevMonth)
        val btnNextMonth = view.findViewById<View>(R.id.btnNextMonth)
        val tvMonthLabel = view.findViewById<TextView>(R.id.tvMonthLabel)

        val db = DBHelper(requireContext()).readableDatabase

        calendarView.topbarVisible = false

        // 상단 월 표시 업데이트
        fun updateMonthLabel(date: CalendarDay) {
            val cal = Calendar.getInstance()
            cal.set(date.year, date.month, 1)
            val fmt = SimpleDateFormat("M월", Locale.KOREA)
            tvMonthLabel.text = fmt.format(cal.time)
        }

        // 달력 새로고침 로직
        fun refreshCalendar(year: Int, month0: Int) {
            val completeDates = mutableListOf<CalendarDay>()
            val partialDates = mutableListOf<CalendarDay>()
            val failDates = mutableListOf<CalendarDay>()

            val cal = Calendar.getInstance()
            cal.set(year, month0, 1)
            val daysInMonth = cal.getActualMaximum(Calendar.DAY_OF_MONTH)

            for (day in 1..daysInMonth) {
                cal.set(year, month0, day)
                val dateStr = dateFormat.format(cal.time)

                // 쿼리: 해당 날짜의 총 스케줄 수와 복용 완료(taken=1)된 스케줄 수 계산
                val cursor = db.rawQuery(
                    """
                    SELECT 
                        COUNT(DISTINCT d.schedule_id) AS total,
                        COUNT(DISTINCT CASE WHEN i.taken = 1 THEN d.schedule_id END) AS taken_count
                    FROM dose_schedule d
                    LEFT JOIN intake_log i 
                      ON i.schedule_id = d.schedule_id 
                     AND i.date = ?
                    WHERE ? BETWEEN d.start_date AND d.end_date
                    """.trimIndent(),
                    arrayOf(dateStr, dateStr)
                )

                if (cursor.moveToFirst()) {
                    val total = cursor.getInt(0)
                    val taken = cursor.getInt(1)

                    // 디버깅 로그: 초록색이 안 나올 경우 Logcat에서 값을 확인하세요.
                    if (total > 0) {
                        Log.d("CalendarCheck", "날짜: $dateStr, 전체: $total, 복용: $taken")
                    }

                    if (total > 0) {
                        val calendarDay = CalendarDay.from(year, month0, day)
                        when {
                            taken >= total -> completeDates.add(calendarDay) // 모두 복용
                            taken == 0 -> failDates.add(calendarDay)         // 미복용
                            else -> partialDates.add(calendarDay)            // 일부 복용
                        }
                    }
                }
                cursor.close()
            }

            // 데코레이터 적용
            calendarView.removeDecorators()
            calendarView.addDecorator(ColorDecorator(Color.parseColor("#2E7D32"), completeDates)) // 초록
            calendarView.addDecorator(ColorDecorator(Color.parseColor("#F59E0B"), partialDates))  // 주황
            calendarView.addDecorator(ColorDecorator(Color.parseColor("#D32F2F"), failDates))     // 빨강

            // 중요: 데코레이터 상태를 즉시 반영
            calendarView.invalidateDecorators()
        }

        // 버튼 리스너
        btnPrevMonth.setOnClickListener { calendarView.goToPrevious() }
        btnNextMonth.setOnClickListener { calendarView.goToNext() }

        // 초기화
        val todayDay = CalendarDay.today()
        calendarView.setSelectedDate(todayDay)
        updateMonthLabel(todayDay)
        refreshCalendar(todayDay.year, todayDay.month)
        showDateDetail(todayDay, db, tvStatus, tvDetail)

        // 리스너 설정
        calendarView.setOnMonthChangedListener { _, date ->
            updateMonthLabel(date)
            refreshCalendar(date.year, date.month)
        }

        calendarView.setOnDateChangedListener { _, date, _ ->
            showDateDetail(date, db, tvStatus, tvDetail)
        }
    }

    private fun showDateDetail(
        date: CalendarDay,
        db: SQLiteDatabase,
        tvStatus: TextView,
        tvDetail: TextView
    ) {
        val selectedDate = String.format("%04d-%02d-%02d", date.year, date.month + 1, date.day)

        val cursor = db.rawQuery(
            """
            SELECT d.time_type, m.name, COALESCE(i.taken, 0)
            FROM dose_schedule d
            JOIN medicine m ON d.medicine_id = m.medicine_id
            LEFT JOIN intake_log i 
              ON i.schedule_id = d.schedule_id 
             AND i.date = ?
            WHERE ? BETWEEN d.start_date AND d.end_date
            ORDER BY 
                CASE d.time_type 
                    WHEN '아침' THEN 1 
                    WHEN '점심' THEN 2 
                    WHEN '저녁' THEN 3 
                    WHEN '취침 전' THEN 4 
                    ELSE 99 
                END
            """.trimIndent(),
            arrayOf(selectedDate, selectedDate)
        )

        val grouped = linkedMapOf<String, MutableList<Pair<String, Boolean>>>()
        while (cursor.moveToNext()) {
            val timeType = cursor.getString(0)
            val name = cursor.getString(1)
            val taken = cursor.getInt(2) == 1
            grouped.getOrPut(timeType) { mutableListOf() }.add(name to taken)
        }
        cursor.close()

        val sb = StringBuilder()
        for (time in listOf("아침", "점심", "저녁", "취침 전")) {
            val list = grouped[time] ?: continue
            sb.append("$time\n")
            for ((name, taken) in list) {
                sb.append("    ${if (taken) "✅" else "❌"} $name\n")
            }
            sb.append("\n")
        }

        tvStatus.text = selectedDate
        tvDetail.text = if (sb.isNotEmpty()) sb.toString().trim() else "등록된 복용 일정이 없습니다."
    }
}