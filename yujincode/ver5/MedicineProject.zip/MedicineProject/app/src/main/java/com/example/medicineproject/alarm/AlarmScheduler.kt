package com.example.medicineproject.alarm

import android.app.AlarmManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import com.example.medicineproject.db.DBHelper
import java.util.*

object AlarmScheduler {

    fun scheduleAll(context: Context) {

        val db = DBHelper(context).readableDatabase
        val cursor = db.rawQuery(
            "SELECT DISTINCT time_type FROM dose_schedule",
            null
        )

        while (cursor.moveToNext()) {
            val timeType = cursor.getString(0)

            val (hour, minute) = when (timeType) {
                "아침" -> 8 to 0
                "점심" -> 12 to 0
                "저녁" -> 18 to 0
                "취침 전" -> 22 to 0
                else -> continue
            }

            setAlarm(context, hour, minute, timeType)
        }
        cursor.close()
    }

    private fun setAlarm(
        context: Context,
        hour: Int,
        minute: Int,
        tag: String
    ) {
        val alarmManager =
            context.getSystemService(Context.ALARM_SERVICE) as AlarmManager

        val intent = Intent(context, MedicineAlarmReceiver::class.java)
        intent.putExtra("timeType", tag)

        val pendingIntent = PendingIntent.getBroadcast(
            context,
            tag.hashCode(),
            intent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        val calendar = Calendar.getInstance().apply {
            set(Calendar.HOUR_OF_DAY, hour)
            set(Calendar.MINUTE, minute)
            set(Calendar.SECOND, 0)
        }

        alarmManager.setRepeating(
            AlarmManager.RTC_WAKEUP,
            calendar.timeInMillis,
            AlarmManager.INTERVAL_DAY,
            pendingIntent
        )
    }
}
