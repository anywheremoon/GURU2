package com.example.medicineproject

import android.os.Bundle
import android.view.View
import android.widget.Button
import android.widget.Switch
import android.widget.Toast
import androidx.fragment.app.Fragment
import com.example.medicineproject.db.DBHelper
import com.example.medicineproject.alarm.AlarmScheduler


class SettingsFragment : Fragment(R.layout.fragment_setting) {

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)


        val btnEnableAlarm = view.findViewById<Button>(R.id.btnEnableAlarm)
        val btnReset = view.findViewById<Button>(R.id.btnReset)


        btnEnableAlarm.setOnClickListener {
            AlarmScheduler.scheduleAll(requireContext())
            Toast.makeText(
                requireContext(),
                "복용 알림 설정 완료",
                Toast.LENGTH_SHORT
            ).show()
        }


        btnReset.setOnClickListener {
            val db = DBHelper(requireContext()).writableDatabase
            db.execSQL("DELETE FROM intake_log")
            Toast.makeText(requireContext(), "데이터 초기화 완료", Toast.LENGTH_SHORT).show()
        }
    }
}