package com.example.medicineproject

import android.graphics.Color
import android.os.Bundle
import android.view.View
import android.widget.TextView
import androidx.fragment.app.Fragment
import com.example.medicineproject.db.DBHelper
import com.example.medicineproject.calendar.ColorDecorator
import com.prolificinteractive.materialcalendarview.CalendarDay
import com.prolificinteractive.materialcalendarview.MaterialCalendarView
import java.util.*

class CalendarFragment : Fragment(R.layout.fragment_calendar) {

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {

        val calendarView = view.findViewById<MaterialCalendarView>(R.id.calendarView)
        val tvStatus = view.findViewById<TextView>(R.id.tvStatus)
        val tvDetail = view.findViewById<TextView>(R.id.tvDetail)

        val db = DBHelper(requireContext()).readableDatabase

        val completeDates = mutableListOf<CalendarDay>()
        val partialDates = mutableListOf<CalendarDay>()
        val failDates = mutableListOf<CalendarDay>()

        val cursor = db.rawQuery(
            """
            SELECT date,
                   COUNT(*) AS total,
                   SUM(taken) AS taken
            FROM intake_log
            GROUP BY date
            """.trimIndent(), null
        )

        while (cursor.moveToNext()) {
            val dateStr = cursor.getString(0)
            val total = cursor.getInt(1)
            val taken = cursor.getInt(2)

            val (y, m, d) = dateStr.split("-")
            val day = CalendarDay.from(
                y.toInt(),
                m.toInt() - 1,
                d.toInt()
            )

            when {
                taken == total -> completeDates.add(day)
                taken > 0 -> partialDates.add(day)
                else -> failDates.add(day)
            }
        }
        cursor.close()

        calendarView.addDecorator(ColorDecorator(Color.GREEN, completeDates))
        calendarView.addDecorator(ColorDecorator(Color.rgb(255, 165, 0), partialDates))
        calendarView.addDecorator(ColorDecorator(Color.RED, failDates))

        calendarView.setOnDateChangedListener { _, date, _ ->
            val selectedDate = String.format(
                "%04d-%02d-%02d",
                date.year,
                date.month + 1,
                date.day
            )

            val detailCursor = db.rawQuery(
                """
                SELECT d.time_type, i.taken
                FROM intake_log i
                JOIN dose_schedule d ON i.schedule_id = d.schedule_id
                WHERE i.date = ?
                """.trimIndent(),
                arrayOf(selectedDate)
            )

            val sb = StringBuilder()
            while (detailCursor.moveToNext()) {
                val time = detailCursor.getString(0)
                val taken = detailCursor.getInt(1) == 1
                sb.append("$time : ${if (taken) "✅" else "❌"}\n")
            }
            detailCursor.close()

            tvStatus.text = selectedDate
            tvDetail.text = sb.toString()
        }
    }
}




