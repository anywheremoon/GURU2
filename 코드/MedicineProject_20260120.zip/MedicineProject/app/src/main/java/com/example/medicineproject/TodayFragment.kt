package com.example.medicineproject

import android.graphics.Color
import android.os.Bundle
import android.view.View
import android.widget.LinearLayout
import android.widget.TextView
import androidx.fragment.app.Fragment
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.example.medicineproject.adapter.DoseSetAdapter
import com.example.medicineproject.db.DBHelper
import com.example.medicineproject.model.DoseItem
import com.example.medicineproject.model.DoseSet
import java.text.SimpleDateFormat
import java.util.*

class TodayFragment : Fragment(R.layout.fragment_today) {

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {

        val tvDate = view.findViewById<TextView>(R.id.tvTodayDate)
        val containerToday = view.findViewById<LinearLayout>(R.id.containerTodayCheck)
        val recyclerView = view.findViewById<RecyclerView>(R.id.recyclerDoseSet)

        recyclerView.layoutManager = LinearLayoutManager(requireContext())

        val today = SimpleDateFormat("yyyy-MM-dd", Locale.getDefault()).format(Date())
        tvDate.text = "📅 오늘 날짜: $today"

        val db = DBHelper(requireContext()).writableDatabase

        // 🔹 공통 쿼리 (하루 기준)
        val cursor = db.rawQuery(
            """
            SELECT d.schedule_id, d.time_type,
                   m.name, d.dose_amount, d.dose_unit,
                   IFNULL(i.taken, 0)
            FROM dose_schedule d
            JOIN medicine m ON d.medicine_id = m.medicine_id
            LEFT JOIN intake_log i
              ON d.schedule_id = i.schedule_id
             AND i.date = ?
            ORDER BY d.time_type
            """.trimIndent(),
            arrayOf(today)
        )

        val map = mutableMapOf<String, MutableList<DoseItem>>()

        while (cursor.moveToNext()) {
            val item = DoseItem(
                scheduleId = cursor.getInt(0),
                name = cursor.getString(2),
                amount = cursor.getInt(3),
                unit = cursor.getString(4),
                taken = cursor.getInt(5) == 1
            )

            val timeType = cursor.getString(1)
            map.getOrPut(timeType) { mutableListOf() }.add(item)
        }
        cursor.close()

        val doseSets = map.map { DoseSet(it.key, it.value) }
        recyclerView.adapter = DoseSetAdapter(doseSets)

        // 🔹 상단 “지금 먹어야 할 약” 표시
        containerToday.removeAllViews()
        for ((time, items) in map) {
            val title = TextView(requireContext())
            title.text = time
            title.textSize = 18f
            containerToday.addView(title)

            for (item in items) {
                val check = TextView(requireContext())
                check.text = "• ${item.name} ${item.amount}${item.unit}"
                check.setTextColor(if (item.taken) Color.GRAY else Color.BLACK)
                containerToday.addView(check)
            }
        }
    }
}




