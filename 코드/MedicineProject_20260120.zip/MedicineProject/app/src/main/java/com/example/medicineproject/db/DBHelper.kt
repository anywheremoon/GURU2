package com.example.medicineproject.db

import android.content.Context
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteOpenHelper

class DBHelper(context: Context) :
    SQLiteOpenHelper(context, "medicine.db", null, 1) {

    override fun onCreate(db: SQLiteDatabase) {

        db.execSQL("""
            CREATE TABLE medicine (
                medicine_id INTEGER PRIMARY KEY AUTOINCREMENT,
                name TEXT NOT NULL,
                photo_uri TEXT,
                category TEXT
            )
        """)

        db.execSQL("""
            CREATE TABLE dose_schedule (
                schedule_id INTEGER PRIMARY KEY AUTOINCREMENT,
                medicine_id INTEGER,
                time_type TEXT,
                time_value TEXT,
                dose_amount INTEGER,
                dose_unit TEXT,
                start_date TEXT,
                end_date TEXT
            )
        """)

        db.execSQL("""
            CREATE TABLE intake_log (
                log_id INTEGER PRIMARY KEY AUTOINCREMENT,
                schedule_id INTEGER,
                date TEXT,
                taken INTEGER
            )
        """)
    }

    override fun onUpgrade(db: SQLiteDatabase, oldVersion: Int, newVersion: Int) {
        db.execSQL("DROP TABLE IF EXISTS medicine")
        db.execSQL("DROP TABLE IF EXISTS dose_schedule")
        db.execSQL("DROP TABLE IF EXISTS intake_log")
        onCreate(db)
    }
}
