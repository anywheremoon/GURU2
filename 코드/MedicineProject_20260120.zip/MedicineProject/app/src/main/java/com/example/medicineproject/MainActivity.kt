package com.example.medicineproject

import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import androidx.fragment.app.Fragment
import com.google.android.material.bottomnavigation.BottomNavigationView
import com.example.medicineproject.SettingsFragment


class MainActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        replaceFragment(TodayFragment())

        findViewById<BottomNavigationView>(R.id.bottomNavigation)
            .setOnItemSelectedListener {
                when (it.itemId) {
                    R.id.menu_today -> replaceFragment(TodayFragment())
                    R.id.menu_calendar -> replaceFragment(CalendarFragment())
                    R.id.menu_medicine -> replaceFragment(MedicineFragment())
                    R.id.menu_setting -> replaceFragment(SettingsFragment())
                }
                true
            }
    }

    private fun replaceFragment(fragment: Fragment) {
        supportFragmentManager.beginTransaction()
            .replace(R.id.container, fragment)
            .commit()
    }
}
