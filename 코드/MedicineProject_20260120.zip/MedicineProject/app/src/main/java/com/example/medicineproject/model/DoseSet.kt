package com.example.medicineproject.model

data class DoseSet(
    val timeType: String,
    val items: MutableList<DoseItem>
)
