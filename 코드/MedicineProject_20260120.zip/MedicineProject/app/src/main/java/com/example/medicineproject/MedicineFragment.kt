package com.example.medicineproject

import android.content.Intent
import android.os.Bundle
import android.view.*
import androidx.fragment.app.Fragment
import com.google.android.material.floatingactionbutton.FloatingActionButton

class MedicineFragment : Fragment() {

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {

        val view = inflater.inflate(R.layout.fragment_medicine, container, false)

        view.findViewById<FloatingActionButton>(R.id.fabAdd)
            .setOnClickListener {
                startActivity(Intent(requireContext(), AddMedicineActivity::class.java))
            }

        return view
    }
}

