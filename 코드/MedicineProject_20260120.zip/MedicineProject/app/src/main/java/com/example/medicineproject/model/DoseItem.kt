package com.example.medicineproject.model

data class DoseItem(
    val scheduleId: Int,
    val name: String,
    val amount: Int,
    val unit: String,
    var taken: Boolean
)
