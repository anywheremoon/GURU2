package com.example.medicineproject.adapter

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.CheckBox
import android.widget.LinearLayout
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import com.example.medicineproject.R
import com.example.medicineproject.db.DBHelper
import com.example.medicineproject.model.DoseSet
import java.text.SimpleDateFormat
import java.util.*

class DoseSetAdapter(
    private val items: List<DoseSet>
) : RecyclerView.Adapter<DoseSetAdapter.ViewHolder>() {

    class ViewHolder(view: View) : RecyclerView.ViewHolder(view) {
        val tvTimeType: TextView = view.findViewById(R.id.tvTimeType)
        val container: LinearLayout = view.findViewById(R.id.containerMedicines)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
        val view = LayoutInflater.from(parent.context)
            .inflate(R.layout.item_dose_set, parent, false)
        return ViewHolder(view)
    }

    override fun getItemCount(): Int = items.size

    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        val doseSet = items[position]

        // ✅ 기존 아이콘 로직 유지
        val icon = when (doseSet.timeType) {
            "아침" -> "🌅"
            "점심" -> "🌞"
            "저녁" -> "🌙"
            "취침 전" -> "🌜"
            else -> "⏰"
        }

        holder.tvTimeType.text = "$icon ${doseSet.timeType} 복용 세트"
        holder.container.removeAllViews()

        val context = holder.itemView.context
        val today = SimpleDateFormat("yyyy-MM-dd", Locale.getDefault()).format(Date())
        val db = DBHelper(context).writableDatabase

        // ✅ 약 목록 하나씩 추가
        for (item in doseSet.items) {
            val row = LayoutInflater.from(context)
                .inflate(R.layout.item_dose_item, holder.container, false)

            val tvMedicine = row.findViewById<TextView>(R.id.tvMedicineInfo)
            val checkBox = row.findViewById<CheckBox>(R.id.checkTaken)

            tvMedicine.text = "- ${item.name} ${item.amount}${item.unit}"
            checkBox.isChecked = item.taken

            checkBox.setOnCheckedChangeListener { _, isChecked ->
                item.taken = isChecked

                val cursor = db.rawQuery(
                    "SELECT log_id FROM intake_log WHERE schedule_id=? AND date=?",
                    arrayOf(item.scheduleId.toString(), today)
                )

                if (cursor.moveToFirst()) {
                    db.execSQL(
                        "UPDATE intake_log SET taken=? WHERE schedule_id=? AND date=?",
                        arrayOf(if (isChecked) 1 else 0, item.scheduleId, today)
                    )
                } else {
                    db.execSQL(
                        "INSERT INTO intake_log (schedule_id, date, taken) VALUES (?, ?, ?)",
                        arrayOf(item.scheduleId, today, if (isChecked) 1 else 0)
                    )
                }
                cursor.close()
            }

            holder.container.addView(row)
        }
    }
}

