package com.example.medicineproject

import android.app.AlertDialog
import android.os.Bundle
import android.view.LayoutInflater
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import com.example.medicineproject.db.DBHelper

class AddMedicineActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_add_medicine)

        val etName = findViewById<EditText>(R.id.etMedicineName)
        val spinnerCategory = findViewById<Spinner>(R.id.spinnerCategory)
        val btnAddSchedule = findViewById<Button>(R.id.btnAddSchedule)
        val btnSave = findViewById<Button>(R.id.btnSaveMedicine)

        // 카테고리 스피너
        spinnerCategory.adapter = ArrayAdapter(
            this,
            android.R.layout.simple_spinner_dropdown_item,
            listOf("영양제", "처방약", "일반약")
        )

        btnAddSchedule.setOnClickListener {
            showAddScheduleDialog()
        }

        btnSave.setOnClickListener {
            val name = etName.text.toString()
            val category = spinnerCategory.selectedItem.toString()

            if (name.isBlank()) {
                Toast.makeText(this, "약 이름을 입력하세요", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }

            val db = DBHelper(this).writableDatabase
            db.execSQL(
                "INSERT INTO medicine(name, category) VALUES (?, ?)",
                arrayOf(name, category)
            )

            Toast.makeText(this, "약 등록 완료", Toast.LENGTH_SHORT).show()
            finish()
        }
    }

    private fun showAddScheduleDialog() {
        val dialogView = LayoutInflater.from(this)
            .inflate(R.layout.dialog_add_schedule, null)

        val spinnerTime = dialogView.findViewById<Spinner>(R.id.spinnerTimeType)
        val etAmount = dialogView.findViewById<EditText>(R.id.etDoseAmount)
        val etUnit = dialogView.findViewById<EditText>(R.id.etDoseUnit)
        val etStart = dialogView.findViewById<EditText>(R.id.etStartDate)
        val etEnd = dialogView.findViewById<EditText>(R.id.etEndDate)

        spinnerTime.adapter = ArrayAdapter(
            this,
            android.R.layout.simple_spinner_dropdown_item,
            listOf("아침", "점심", "저녁", "취침 전")
        )

        AlertDialog.Builder(this)
            .setTitle("복용 일정 추가")
            .setView(dialogView)
            .setPositiveButton("추가") { _, _ ->

                val timeType = spinnerTime.selectedItem.toString()
                val amount = etAmount.text.toString().toIntOrNull() ?: 1
                val unit = etUnit.text.toString()
                val startDate = etStart.text.toString()
                val endDate = etEnd.text.toString()

                val db = DBHelper(this).writableDatabase

                val cursor = db.rawQuery(
                    "SELECT medicine_id FROM medicine ORDER BY medicine_id DESC LIMIT 1",
                    null
                )

                if (cursor.moveToFirst()) {
                    val medicineId = cursor.getInt(0)

                    db.execSQL(
                        """
                        INSERT INTO dose_schedule(
                            medicine_id, time_type, dose_amount, dose_unit, start_date, end_date
                        ) VALUES (?, ?, ?, ?, ?, ?)
                        """.trimIndent(),
                        arrayOf(
                            medicineId,
                            timeType,
                            amount,
                            unit,
                            startDate,
                            endDate
                        )
                    )
                }
                cursor.close()
            }
            .setNegativeButton("취소", null)
            .show()
    }
}

